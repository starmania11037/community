
#include "complaintrecordpage.h"
#include "ui_complaintrecordpage.h"
#include "databasemanager.h"
#include <QScrollBar>
#include <QLabel>
#include <QMessageBox> // 确保包含此头文件

ComplaintRecordPage::ComplaintRecordPage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ComplaintRecordPage) {
    ui->setupUi(this);
    initUI(); // 初始化UI和布局
    loadComplaintsFromDatabase(); // 加载数据
}

ComplaintRecordPage::~ComplaintRecordPage() {
    delete ui;
}

// 初始化UI布局（不变）
void ComplaintRecordPage::initUI() {
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(10, 10, 10, 10);
    // 1. 标题
    QLabel* titleLabel = new QLabel("投诉记录表", this);
    titleLabel->setStyleSheet("color: blue; font-size: 24px; font-weight: bold;");
    titleLabel->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(titleLabel);
    // 2. 表格
    tableWidget = new QTableWidget(this);
    tableWidget->setColumnCount(4); // 对应字段：ID、内容、时间、已处理
    tableWidget->setHorizontalHeaderLabels({"ID", "内容", "时间", "已处理"});
    tableWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    tableWidget->horizontalHeader()->setStretchLastSection(true);
    tableWidget->verticalHeader()->setVisible(false);
    mainLayout->addWidget(tableWidget, 10);
    // 3. 按钮
    btnMark = new QPushButton("标记选中项为已处理", this);
    btnMark->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    connect(btnMark, &QPushButton::clicked, this, &ComplaintRecordPage::onMarkHandled);
    mainLayout->addWidget(btnMark, 0, Qt::AlignCenter);
    mainLayout->setSpacing(10);
}

// 从try.db的complaints表加载数据
void ComplaintRecordPage::loadComplaintsFromDatabase() {
    DatabaseManager dbManager;
    // 打开try.db数据库（替换原complaint.db）
    if (dbManager.open("try.db")) {
        // 查询complaints表（替换原complaint表）
        QSqlQuery query(dbManager.db);
        query.exec("SELECT complaintid, description, date, status FROM complaints");

        QList<QVariantList> complaints;
        while (query.next()) {
            complaints.append({
                query.value(0), // complaintid（对应原ID）
                query.value(1), // description（对应原内容）
                query.value(2), // date（对应原时间）
                query.value(3).toBool() // status（对应原"已处理"状态，1为已处理，0为未处理）
            });
        }

        // 填充表格
        tableWidget->setRowCount(complaints.size());
        for (int i = 0; i < complaints.size(); ++i) {
            const QVariantList& complaint = complaints[i];
            tableWidget->setItem(i, 0, new QTableWidgetItem(complaint[0].toString()));
            tableWidget->setItem(i, 1, new QTableWidgetItem(complaint[1].toString()));
            tableWidget->setItem(i, 2, new QTableWidgetItem(complaint[2].toString()));
            QCheckBox* handledCheck = new QCheckBox();
            handledCheck->setChecked(complaint[3].toBool());
            tableWidget->setCellWidget(i, 3, handledCheck);
        }
        dbManager.close();
    } else {
        QMessageBox::critical(this, "数据库错误", "无法打开try.db数据库！");
    }
}

// 标记选中项为已处理（更新到try.db的complaints表）
void ComplaintRecordPage::onMarkHandled() {
    DatabaseManager dbManager;
    if (dbManager.open("try.db")) {
        for (int i = 0; i < tableWidget->rowCount(); ++i) {
            if (tableWidget->item(i, 0)->isSelected()) {
                int id = tableWidget->item(i, 0)->text().toInt();
                QCheckBox* handledCheck = qobject_cast<QCheckBox*>(tableWidget->cellWidget(i, 3));
                bool handled = handledCheck ? handledCheck->isChecked() : false;

                // 更新complaints表的status字段（1为已处理，0为未处理）
                QSqlQuery query(dbManager.db);
                query.prepare("UPDATE complaints SET status = :status WHERE complaintid = :id");
                query.bindValue(":status", handled ? 1 : 0);
                query.bindValue(":id", id);
                query.exec();
            }
        }
        dbManager.close();
        QMessageBox::information(this, "提示", "选中的投诉状态已更新！");
        // 重新加载数据刷新表格
        loadComplaintsFromDatabase();
    } else {
        QMessageBox::critical(this, "数据库错误", "无法打开try.db数据库！");
    }
}
