
#ifndef FEEREPORTPAGE_H
#define FEEREPORTPAGE_H

#include <QWidget>
#include <QTableView>
#include <QStandardItemModel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QPdfWriter>
#include <QPainter>
#include <QComboBox>
#include "databasemanager.h"

class FeeReportPage : public QWidget
{
    Q_OBJECT

public:
    explicit FeeReportPage(QWidget *parent = nullptr);
    ~FeeReportPage();
    QTableView *tableView;

private slots:
    void generateReport();
    void exportToPDF();

private:
    QPushButton *generateButton;
    QPushButton *exportButton;
    QStandardItemModel* model;
    DatabaseManager db;
    QComboBox *reportTypeComboBox; // 添加下拉框成员变量
    void loadDataFromDatabase(const QString& reportType); // 修改函数以接受报表类型参数
};

#endif // FEEREPORTPAGE_H
