
#ifndef COMPLAINTRECORDPAGE_H
#define COMPLAINTRECORDPAGE_H

#include <QWidget>
#include <QHeaderView>
#include <QTableWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QCheckBox>
#include "databasemanager.h"

namespace Ui {
class ComplaintRecordPage;
}

class ComplaintRecordPage : public QWidget {
    Q_OBJECT

public:
    explicit ComplaintRecordPage(QWidget *parent = nullptr);
    ~ComplaintRecordPage();
    QTableWidget *tableWidget;    // 投诉表格

private slots:
    void onMarkHandled();          // 处理"标记已处理"按钮点击
    void loadComplaintsFromDatabase(); // 从数据库加载投诉数据

private:
    Ui::ComplaintRecordPage *ui;

    QPushButton *btnMark;          // "标记已处理"按钮
    void initUI();                 // 初始化界面布局
};

#endif // COMPLAINTRECORDPAGE_H

