#include <QApplication>
#include "adminwindow.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    AdminWindow w;
    w.show();
    return app.exec();
}
