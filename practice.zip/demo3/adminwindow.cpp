
//#include "adminwindow.h"
//#include "dailyexpensedetailpage.h"
//#include "dailyincomedetailpage.h"
//#include "monthlyexpensedetailpage.h"
//#include "monthlyincomedetailpage.h"
//#include "yearlyexpensedetailpage.h"
//#include "yearlyincomedetailpage.h"
//#include <QVBoxLayout>
//#include <QHBoxLayout>
//#include <QPushButton>
//#include <QLabel>

//AdminWindow::AdminWindow(QWidget *parent) : QMainWindow(parent) {
//    QWidget* central = new QWidget(this);
//    QHBoxLayout* mainLayout = new QHBoxLayout(central);

//    // 左侧导航栏
//    QVBoxLayout* navLayout = new QVBoxLayout();
//    financeCenterButton = new QPushButton("财务中心", this);
//    userFeedbackButton = new QPushButton("用户反馈", this);
//    incomeButton = new QPushButton("收入明细", this);
//    expenditureButton = new QPushButton("支出明细", this);
//    complaintButton = new QPushButton("投诉记录", this);
//    feeReportButton = new QPushButton("费用报表生成", this);

//    dailyIncomeButton = new QPushButton("日收入明细", this);
//    monthlyIncomeButton = new QPushButton("月收入明细", this);
//    yearlyIncomeButton = new QPushButton("年收入明细", this);
//    dailyExpenseButton = new QPushButton("日支出明细", this);
//    monthlyExpenseButton = new QPushButton("月支出明细", this);
//    yearlyExpenseButton = new QPushButton("年支出明细", this);

//    // 设置按钮样式
//    financeCenterButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; font-weight: bold;");
//    userFeedbackButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; font-weight: bold;");
//    incomeButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 20px;");
//    expenditureButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 20px;");
//    feeReportButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 20px;");
//    complaintButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 20px;");
//    dailyIncomeButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");
//    monthlyIncomeButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");
//    yearlyIncomeButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");
//    dailyExpenseButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");
//    monthlyExpenseButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");
//    yearlyExpenseButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");

//    // 连接按钮点击事件
//    connect(financeCenterButton, &QPushButton::clicked, [this]() { /* 展开财务中心子菜单 */ });
//    connect(userFeedbackButton, &QPushButton::clicked, [this]() { /* 展开用户反馈子菜单 */ });
//    connect(incomeButton, &QPushButton::clicked, [this]() { showPage(0); });
//    connect(expenditureButton, &QPushButton::clicked, [this]() { showPage(1); });
//    connect(complaintButton, &QPushButton::clicked, [this]() { showPage(2); });
//    connect(feeReportButton, &QPushButton::clicked, [this]() { showPage(3); });
//    connect(dailyIncomeButton, &QPushButton::clicked, this, &AdminWindow::showDailyIncomePage);
//    connect(monthlyIncomeButton, &QPushButton::clicked, this, &AdminWindow::showMonthlyIncomePage);
//    connect(yearlyIncomeButton, &QPushButton::clicked, this, &AdminWindow::showYearlyIncomePage);
//    connect(dailyExpenseButton, &QPushButton::clicked, this, &AdminWindow::showDailyExpensePage);
//    connect(monthlyExpenseButton, &QPushButton::clicked, this, &AdminWindow::showMonthlyExpensePage);
//    connect(yearlyExpenseButton, &QPushButton::clicked, this, &AdminWindow::showYearlyExpensePage);

//    navLayout->addWidget(financeCenterButton);
//    navLayout->addWidget(incomeButton);
//    navLayout->addWidget(dailyIncomeButton);
//    navLayout->addWidget(monthlyIncomeButton);
//    navLayout->addWidget(yearlyIncomeButton);
//    navLayout->addWidget(expenditureButton);
//    navLayout->addWidget(dailyExpenseButton);
//    navLayout->addWidget(monthlyExpenseButton);
//    navLayout->addWidget(yearlyExpenseButton);
//    navLayout->addWidget(feeReportButton);
//    navLayout->addWidget(userFeedbackButton);
//    navLayout->addWidget(complaintButton);
//    navLayout->addStretch();

//    mainLayout->addLayout(navLayout);

//    // 页面栈
//    stackedWidget = new QStackedWidget(this);
//    stackedWidget->addWidget(new IncomeDetailPage());
//    stackedWidget->addWidget(new ExpenditureDetailPage());
//    stackedWidget->addWidget(new ComplaintRecordPage());
//    stackedWidget->addWidget(new FeeReportPage());

//    // 添加新页面
//    dailyIncomePage = new DailyIncomeDetailPage();
//    monthlyIncomePage = new MonthlyIncomeDetailPage();
//    yearlyIncomePage = new YearlyIncomeDetailPage();
//    dailyExpensePage = new DailyExpenseDetailPage();
//    monthlyExpensePage = new MonthlyExpenseDetailPage();
//    yearlyExpensePage = new YearlyExpenseDetailPage();

//    stackedWidget->addWidget(dailyIncomePage);
//    stackedWidget->addWidget(monthlyIncomePage);
//    stackedWidget->addWidget(yearlyIncomePage);
//    stackedWidget->addWidget(dailyExpensePage);
//    stackedWidget->addWidget(monthlyExpensePage);
//    stackedWidget->addWidget(yearlyExpensePage);

//    mainLayout->addWidget(stackedWidget);

//    setCentralWidget(central);
//    setWindowTitle("管理系统");
//    resize(1000, 600);

//    // 默认显示收入明细页面
//    showPage(0);
//}

//void AdminWindow::showPage(int index) {
//    stackedWidget->setCurrentIndex(index);

//    // 仅在页面存在时设置样式
//    if (index == 0) {
//        IncomeDetailPage* incomePage = qobject_cast<IncomeDetailPage*>(stackedWidget->widget(index));
//        if (incomePage && incomePage->summaryTable) {
//            incomePage->summaryTable->setStyleSheet("QHeaderView::section {"
//                                                  "background-color: #0055ff;"
//                                                  "color: white;"
//                                                  "}"
//                                                  "QTableWidget::item:alternate {"
//                                                  "background-color: #f2f2f2;"
//                                                  "}");
//        }
//    } else if (index == 1) {
//        ExpenditureDetailPage* expenditurePage = qobject_cast<ExpenditureDetailPage*>(stackedWidget->widget(index));
//        if (expenditurePage && expenditurePage->summaryTable) {
//            expenditurePage->summaryTable->setStyleSheet("QHeaderView::section {"
//                                                       "background-color: #0055ff;"
//                                                       "color: white;"
//                                                       "}"
//                                                       "QTableWidget::item:alternate {"
//                                                       "background-color: #f2f2f2;"
//                                                       "}");
//        }
//    } else if (index == 2) {
//        ComplaintRecordPage* complaintPage = qobject_cast<ComplaintRecordPage*>(stackedWidget->widget(index));
//        if (complaintPage && complaintPage->tableWidget) {
//            complaintPage->tableWidget->setStyleSheet("QHeaderView::section {"
//                                                     "background-color: #0055ff;"
//                                                     "color: white;"
//                                                     "}"
//                                                     "QTableWidget::item:alternate {"
//                                                     "background-color: #f2f2f2;"
//                                                     "}");
//        }
//    } else if (index == 3) {
//        FeeReportPage* feeReportPage = qobject_cast<FeeReportPage*>(stackedWidget->widget(index));
//        if (feeReportPage && feeReportPage->tableView) {
//            feeReportPage->tableView->setStyleSheet("QHeaderView::section {"
//                                                  "background-color: #0055ff;"
//                                                  "color: white;"
//                                                  "}"
//                                                  "QTableView::item:alternate {"
//                                                  "background-color: #f2f2f2;"
//                                                  "}");
//        }
//    }
//}

//void AdminWindow::showDailyIncomePage() {
//    int index = stackedWidget->indexOf(dailyIncomePage);
//    if (index != -1) {
//        stackedWidget->setCurrentIndex(index);
//    }
//}

//void AdminWindow::showMonthlyIncomePage() {
//    int index = stackedWidget->indexOf(monthlyIncomePage);
//    if (index != -1) {
//        stackedWidget->setCurrentIndex(index);
//    }
//}

//void AdminWindow::showYearlyIncomePage() {
//    int index = stackedWidget->indexOf(yearlyIncomePage);
//    if (index != -1) {
//        stackedWidget->setCurrentIndex(index);
//    }
//}

//void AdminWindow::showDailyExpensePage() {
//    int index = stackedWidget->indexOf(dailyExpensePage);
//    if (index != -1) {
//        stackedWidget->setCurrentIndex(index);
//    }
//}

//void AdminWindow::showMonthlyExpensePage() {
//    int index = stackedWidget->indexOf(monthlyExpensePage);
//    if (index != -1) {
//        stackedWidget->setCurrentIndex(index);
//    }
//}

//void AdminWindow::showYearlyExpensePage() {
//    int index = stackedWidget->indexOf(yearlyExpensePage);
//    if (index != -1) {
//        stackedWidget->setCurrentIndex(index);
//    }
//}
#include "adminwindow.h"
#include "dailyexpensedetailpage.h"
#include "dailyincomedetailpage.h"
#include "monthlyexpensedetailpage.h"
#include "monthlyincomedetailpage.h"
#include "yearlyexpensedetailpage.h"
#include "yearlyincomedetailpage.h"
#include "databasemanager.h" // 添加数据库管理器头文件
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QMessageBox>

AdminWindow::AdminWindow(QWidget *parent) : QMainWindow(parent) {
    QWidget* central = new QWidget(this);
    QHBoxLayout* mainLayout = new QHBoxLayout(central);

    // 左侧导航栏
    QVBoxLayout* navLayout = new QVBoxLayout();
    financeCenterButton = new QPushButton("财务中心", this);
    userFeedbackButton = new QPushButton("用户反馈", this);
    incomeButton = new QPushButton("收入明细", this);
    expenditureButton = new QPushButton("支出明细", this);
    complaintButton = new QPushButton("投诉记录", this);
    feeReportButton = new QPushButton("费用报表生成", this);

    dailyIncomeButton = new QPushButton("日收入明细", this);
    monthlyIncomeButton = new QPushButton("月收入明细", this);
    yearlyIncomeButton = new QPushButton("年收入明细", this);
    dailyExpenseButton = new QPushButton("日支出明细", this);
    monthlyExpenseButton = new QPushButton("月支出明细", this);
    yearlyExpenseButton = new QPushButton("年支出明细", this);

    // 设置按钮样式
    financeCenterButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; font-weight: bold;");
    userFeedbackButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; font-weight: bold;");
    incomeButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 20px;");
    expenditureButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 20px;");
    feeReportButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 20px;");
    complaintButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 20px;");
    dailyIncomeButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");
    monthlyIncomeButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");
    yearlyIncomeButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");
    dailyExpenseButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");
    monthlyExpenseButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");
    yearlyExpenseButton->setStyleSheet("background-color: #0055ff; color: white; padding: 6px 12px; margin-left: 40px;");

    // 连接按钮点击事件
    connect(financeCenterButton, &QPushButton::clicked, [this]() { /* 展开财务中心子菜单 */ });
    connect(userFeedbackButton, &QPushButton::clicked, [this]() { /* 展开用户反馈子菜单 */ });
    connect(incomeButton, &QPushButton::clicked, [this]() { showPage(0); });
    connect(expenditureButton, &QPushButton::clicked, [this]() { showPage(1); });
    connect(complaintButton, &QPushButton::clicked, [this]() { showPage(2); });
    connect(feeReportButton, &QPushButton::clicked, [this]() { showPage(3); });
    connect(dailyIncomeButton, &QPushButton::clicked, this, &AdminWindow::showDailyIncomePage);
    connect(monthlyIncomeButton, &QPushButton::clicked, this, &AdminWindow::showMonthlyIncomePage);
    connect(yearlyIncomeButton, &QPushButton::clicked, this, &AdminWindow::showYearlyIncomePage);
    connect(dailyExpenseButton, &QPushButton::clicked, this, &AdminWindow::showDailyExpensePage);
    connect(monthlyExpenseButton, &QPushButton::clicked, this, &AdminWindow::showMonthlyExpensePage);
    connect(yearlyExpenseButton, &QPushButton::clicked, this, &AdminWindow::showYearlyExpensePage);

    navLayout->addWidget(financeCenterButton);
    navLayout->addWidget(incomeButton);
    navLayout->addWidget(dailyIncomeButton);
    navLayout->addWidget(monthlyIncomeButton);
    navLayout->addWidget(yearlyIncomeButton);
    navLayout->addWidget(expenditureButton);
    navLayout->addWidget(dailyExpenseButton);
    navLayout->addWidget(monthlyExpenseButton);
    navLayout->addWidget(yearlyExpenseButton);
    navLayout->addWidget(feeReportButton);
    navLayout->addWidget(userFeedbackButton);
    navLayout->addWidget(complaintButton);
    navLayout->addStretch();

    mainLayout->addLayout(navLayout);

    // 页面栈
    stackedWidget = new QStackedWidget(this);
    stackedWidget->addWidget(new IncomeDetailPage());
    stackedWidget->addWidget(new ExpenditureDetailPage());
    stackedWidget->addWidget(new ComplaintRecordPage());
    stackedWidget->addWidget(new FeeReportPage());

    // 添加新页面
    dailyIncomePage = new DailyIncomeDetailPage();
    monthlyIncomePage = new MonthlyIncomeDetailPage();
    yearlyIncomePage = new YearlyIncomeDetailPage();
    dailyExpensePage = new DailyExpenseDetailPage();
    monthlyExpensePage = new MonthlyExpenseDetailPage();
    yearlyExpensePage = new YearlyExpenseDetailPage();

    stackedWidget->addWidget(dailyIncomePage);
    stackedWidget->addWidget(monthlyIncomePage);
    stackedWidget->addWidget(yearlyIncomePage);
    stackedWidget->addWidget(dailyExpensePage);
    stackedWidget->addWidget(monthlyExpensePage);
    stackedWidget->addWidget(yearlyExpensePage);

    mainLayout->addWidget(stackedWidget);

    setCentralWidget(central);
    setWindowTitle("管理系统");
    resize(1000, 600);

    // 默认显示收入明细页面
    showPage(0);
}

// 执行数据库操作并显示页面
void AdminWindow::executeDbOperationsAndShowPage(int index) {
    // 只在显示收入或支出页面时执行数据库操作
    if (index >= 0 && index <= 1) {
        DatabaseManager db;
        if (db.open("try.db")) {
            // 执行数据库插入操作
            db.processParkingSpaceData();
            db.transferAttendanceToExpense();
            db.close();
        } else {
            QMessageBox::critical(this, "数据库错误", "无法打开数据库");
            return;
        }
    }

    // 显示页面
    stackedWidget->setCurrentIndex(index);

    // 设置表格样式
    if (index == 0) {
        IncomeDetailPage* incomePage = qobject_cast<IncomeDetailPage*>(stackedWidget->widget(index));
        if (incomePage && incomePage->summaryTable) {
            incomePage->summaryTable->setStyleSheet("QHeaderView::section {"
                                                  "background-color: #0055ff;"
                                                  "color: white;"
                                                  "}"
                                                  "QTableWidget::item:alternate {"
                                                  "background-color: #f2f2f2;"
                                                  "}");
        }
    } else if (index == 1) {
        ExpenditureDetailPage* expenditurePage = qobject_cast<ExpenditureDetailPage*>(stackedWidget->widget(index));
        if (expenditurePage && expenditurePage->summaryTable) {
            expenditurePage->summaryTable->setStyleSheet("QHeaderView::section {"
                                                       "background-color: #0055ff;"
                                                       "color: white;"
                                                       "}"
                                                       "QTableWidget::item:alternate {"
                                                       "background-color: #f2f2f2;"
                                                       "}");
        }
    } else if (index == 2) {
        ComplaintRecordPage* complaintPage = qobject_cast<ComplaintRecordPage*>(stackedWidget->widget(index));
        if (complaintPage && complaintPage->tableWidget) {
            complaintPage->tableWidget->setStyleSheet("QHeaderView::section {"
                                                     "background-color: #0055ff;"
                                                     "color: white;"
                                                     "}"
                                                     "QTableWidget::item:alternate {"
                                                     "background-color: #f2f2f2;"
                                                     "}");
        }
    } else if (index == 3) {
        FeeReportPage* feeReportPage = qobject_cast<FeeReportPage*>(stackedWidget->widget(index));
        if (feeReportPage && feeReportPage->tableView) {
            feeReportPage->tableView->setStyleSheet("QHeaderView::section {"
                                                  "background-color: #0055ff;"
                                                  "color: white;"
                                                  "}"
                                                  "QTableView::item:alternate {"
                                                  "background-color: #f2f2f2;"
                                                  "}");
        }
    }
}

void AdminWindow::showPage(int index) {
    executeDbOperationsAndShowPage(index);
}

void AdminWindow::showDailyIncomePage() {
    executeDbOperationsAndShowPage(stackedWidget->indexOf(dailyIncomePage));
}

void AdminWindow::showMonthlyIncomePage() {
    executeDbOperationsAndShowPage(stackedWidget->indexOf(monthlyIncomePage));
}

void AdminWindow::showYearlyIncomePage() {
    executeDbOperationsAndShowPage(stackedWidget->indexOf(yearlyIncomePage));
}

void AdminWindow::showDailyExpensePage() {
    executeDbOperationsAndShowPage(stackedWidget->indexOf(dailyExpensePage));
}

void AdminWindow::showMonthlyExpensePage() {
    executeDbOperationsAndShowPage(stackedWidget->indexOf(monthlyExpensePage));
}

void AdminWindow::showYearlyExpensePage() {
    executeDbOperationsAndShowPage(stackedWidget->indexOf(yearlyExpensePage));
}
