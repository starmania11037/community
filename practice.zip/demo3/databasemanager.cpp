
#include "databasemanager.h"
#include <QDebug>

bool DatabaseManager::open(const QString& dbName) {
    // 连接名使用唯一标识
    QString connName = "conn_try.db";

    // 如果连接已存在，先关闭旧连接
    if (QSqlDatabase::contains(connName)) {
        QSqlDatabase existingDb = QSqlDatabase::database(connName);
        if (existingDb.isOpen()) {
            existingDb.close();
        }
        QSqlDatabase::removeDatabase(connName);
    }

    // 创建新连接
    db = QSqlDatabase::addDatabase("QSQLITE", connName);
    db.setDatabaseName("try.db");
    return db.open();
}

void DatabaseManager::close() {
    if (db.isOpen()) {
        db.close();
    }
    // 移除连接前确保没有查询在使用
    QString connName = db.connectionName();
    if (QSqlDatabase::contains(connName)) {
        QSqlDatabase::removeDatabase(connName);
    }
}

QList<QVariantList> DatabaseManager::getComplaints() {
    QList<QVariantList> data;
    if (!db.isOpen()) return data;

    QSqlQuery query(db); // 绑定当前连接
    query.exec("SELECT id, content, time, handled FROM complaint");
    while (query.next()) {
        data.append({
            query.value(0),
            query.value(1),
            query.value(2),
            query.value(3).toBool()
        });
    }
    return data;
}

double DatabaseManager::getIncomeSum(const QString& type) {
    if (!db.isOpen()) return 0.0;
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM income WHERE type = :type");
    query.bindValue(":type", type);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getExpenseSum(const QString& type) {
    if (!db.isOpen()) return 0.0;
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM expense WHERE type = :type");
    query.bindValue(":type", type);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

bool DatabaseManager::updateComplaintStatus(int id, bool handled) {
    if (!db.isOpen()) {
        qDebug() << "Database is not open!";
        return false;
    }
    QSqlQuery query(db);
    query.prepare("UPDATE complaint SET handled = :handled WHERE id = :id");
    query.bindValue(":handled", handled ? 1 : 0);
    query.bindValue(":id", id);
    if (query.exec()) {
        return query.numRowsAffected() > 0;
    } else {
        qDebug() << "Update failed:" << query.lastError().text();
        return false;
    }
}

void DatabaseManager::processParkingSpaceData() {
    if (!db.isOpen()) return;
    QSqlQuery query(db);
    query.exec("SELECT username, location, phonenumber, start_date, end_date FROM parkingspace");
    while (query.next()) {
        QString username = query.value(0).toString();
        QString location = query.value(1).toString();
        QString phonenumber = query.value(2).toString();
        QDate startDate = query.value(3).toDate();
        QDate endDate = query.value(4).toDate();

        int paymentPeriod;
        double payable, paid;
        int method;
        if (endDate.isNull()) {
            paymentPeriod = 12;
            payable = paid = 300000;
            method = 0;
        } else {
            int months = (endDate.year() - startDate.year()) * 12 + endDate.month() - startDate.month();
            if (endDate.day() > startDate.day()) {
                months++;
            }
            paymentPeriod = months;
            payable = paid = 600;
            method = 1;
        }

        QSqlQuery insertQuery(db);
        insertQuery.prepare("INSERT INTO payment (username, location, phonenumber, paymentperiod, type, payable, paid, paymenttime, method) VALUES (:username, :location, :phonenumber, :paymentPeriod, 2, :payable, :paid, :paymenttime, :method)");
        insertQuery.bindValue(":username", username);
        insertQuery.bindValue(":location", location);
        insertQuery.bindValue(":phonenumber", phonenumber);
        insertQuery.bindValue(":paymentPeriod", paymentPeriod);
        insertQuery.bindValue(":payable", payable);
        insertQuery.bindValue(":paid", paid);
        insertQuery.bindValue(":paymenttime", startDate);
        insertQuery.bindValue(":method", method);
        insertQuery.exec();
    }
}

void DatabaseManager::transferPaymentToIncome() {
    if (!db.isOpen()) return;
    QSqlQuery query(db);
    query.exec("SELECT paymenttime, type, paid FROM payment");
    while (query.next()) {
        QDate date = query.value(0).toDate();
        int type = query.value(1).toInt();
        double amount = query.value(2).toDouble();
        QString incomeType;
        if (type == 1) {
            incomeType = "物业费";
        } else if (type == 2) {
            incomeType = "车位费";
        }

        QSqlQuery insertQuery(db);
        insertQuery.prepare("INSERT INTO income (date, type, amount) VALUES (:date, :type, :amount)");
        insertQuery.bindValue(":date", date);
        insertQuery.bindValue(":type", incomeType);
        insertQuery.bindValue(":amount", amount);
        insertQuery.exec();
    }
}

void DatabaseManager::transferAttendanceToExpense() {
    if (!db.isOpen()) return;
    QSqlQuery query(db);
    query.exec("SELECT month, status, leavenumber, absentnumber FROM attendances");
    while (query.next()) {
        QDate month = query.value(0).toDate();
        int status = query.value(1).toInt();
        int leaveNumber = query.value(2).toInt();
        int absentNumber = query.value(3).toInt();

        QDate paymentDate = month.addMonths(1).addDays(14); // 下一个月的15号
        double amount;
        if (status == 1) {
            amount = month.daysInMonth() * 300 + 900;
        } else {
            amount = (month.daysInMonth() - leaveNumber) * 300 - 600 * absentNumber;
        }

        QSqlQuery insertQuery(db);
        insertQuery.prepare("INSERT INTO expense (date, type, amount) VALUES (:date, '工资', :amount)");
        insertQuery.bindValue(":date", paymentDate);
        insertQuery.bindValue(":amount", amount);
        insertQuery.exec();
    }
}

double DatabaseManager::getYesterdayIncome() {
    if (!db.isOpen()) return 0.0;
    QDate yesterday = QDate::currentDate().addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM income WHERE date = :date");
    query.bindValue(":date", yesterday);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getYesterdayPropertyFeeIncome() {
    if (!db.isOpen()) return 0.0;
    QDate yesterday = QDate::currentDate().addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM income WHERE date = :date AND type = '物业费'");
    query.bindValue(":date", yesterday);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getYesterdayParkingFeeIncome() {
    if (!db.isOpen()) return 0.0;
    QDate yesterday = QDate::currentDate().addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM income WHERE date = :date AND type = '车位费'");
    query.bindValue(":date", yesterday);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastMonthIncome() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastMonth = currentDate.addMonths(-1).addDays(-currentDate.day() + 1);
    QDate endOfLastMonth = startOfLastMonth.addMonths(1).addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM income WHERE date BETWEEN :start AND :end");
    query.bindValue(":start", startOfLastMonth);
    query.bindValue(":end", endOfLastMonth);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastMonthPropertyFeeIncome() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastMonth = currentDate.addMonths(-1).addDays(-currentDate.day() + 1);
    QDate endOfLastMonth = startOfLastMonth.addMonths(1).addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM income WHERE date BETWEEN :start AND :end AND type = '物业费'");
    query.bindValue(":start", startOfLastMonth);
    query.bindValue(":end", endOfLastMonth);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastMonthParkingFeeIncome() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastMonth = currentDate.addMonths(-1).addDays(-currentDate.day() + 1);
    QDate endOfLastMonth = startOfLastMonth.addMonths(1).addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM income WHERE date BETWEEN :start AND :end AND type = '车位费'");
    query.bindValue(":start", startOfLastMonth);
    query.bindValue(":end", endOfLastMonth);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastYearIncome() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastYear = QDate(currentDate.year() - 1, 1, 1);
    QDate endOfLastYear = QDate(currentDate.year() - 1, 12, 31);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM income WHERE date BETWEEN :start AND :end");
    query.bindValue(":start", startOfLastYear);
    query.bindValue(":end", endOfLastYear);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastYearPropertyFeeIncome() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastYear = QDate(currentDate.year() - 1, 1, 1);
    QDate endOfLastYear = QDate(currentDate.year() - 1, 12, 31);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM income WHERE date BETWEEN :start AND :end AND type = '物业费'");
    query.bindValue(":start", startOfLastYear);
    query.bindValue(":end", endOfLastYear);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastYearParkingFeeIncome() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastYear = QDate(currentDate.year() - 1, 1, 1);
    QDate endOfLastYear = QDate(currentDate.year() - 1, 12, 31);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM income WHERE date BETWEEN :start AND :end AND type = '车位费'");
    query.bindValue(":start", startOfLastYear);
    query.bindValue(":end", endOfLastYear);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getYesterdayExpense() {
    if (!db.isOpen()) return 0.0;
    QDate yesterday = QDate::currentDate().addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM expense WHERE date = :date");
    query.bindValue(":date", yesterday);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getYesterdayMaintenanceExpense() {
    if (!db.isOpen()) return 0.0;
    QDate yesterday = QDate::currentDate().addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM expense WHERE date = :date AND type = '维修费'");
    query.bindValue(":date", yesterday);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getYesterdaySalaryExpense() {
    if (!db.isOpen()) return 0.0;
    if (QDate::currentDate().day() != 16) return 0.0;
    QDate yesterday = QDate::currentDate().addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM expense WHERE date = :date AND type = '工资'");
    query.bindValue(":date", yesterday);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastMonthExpense() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastMonth = currentDate.addMonths(-1).addDays(-currentDate.day() + 1);
    QDate endOfLastMonth = startOfLastMonth.addMonths(1).addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM expense WHERE date BETWEEN :start AND :end");
    query.bindValue(":start", startOfLastMonth);
    query.bindValue(":end", endOfLastMonth);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastMonthMaintenanceExpense() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastMonth = currentDate.addMonths(-1).addDays(-currentDate.day() + 1);
    QDate endOfLastMonth = startOfLastMonth.addMonths(1).addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM expense WHERE date BETWEEN :start AND :end AND type = '维修费'");
    query.bindValue(":start", startOfLastMonth);
    query.bindValue(":end", endOfLastMonth);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastMonthSalaryExpense() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastMonth = currentDate.addMonths(-1).addDays(-currentDate.day() + 1);
    QDate endOfLastMonth = startOfLastMonth.addMonths(1).addDays(-1);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM expense WHERE date BETWEEN :start AND :end AND type = '工资'");
    query.bindValue(":start", startOfLastMonth);
    query.bindValue(":end", endOfLastMonth);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastYearExpense() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastYear = QDate(currentDate.year() - 1, 1, 1);
    QDate endOfLastYear = QDate(currentDate.year() - 1, 12, 31);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM expense WHERE date BETWEEN :start AND :end");
    query.bindValue(":start", startOfLastYear);
    query.bindValue(":end", endOfLastYear);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastYearMaintenanceExpense() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastYear = QDate(currentDate.year() - 1, 1, 1);
    QDate endOfLastYear = QDate(currentDate.year() - 1, 12, 31);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM expense WHERE date BETWEEN :start AND :end AND type = '维修费'");
    query.bindValue(":start", startOfLastYear);
    query.bindValue(":end", endOfLastYear);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}

double DatabaseManager::getLastYearSalaryExpense() {
    if (!db.isOpen()) return 0.0;
    QDate currentDate = QDate::currentDate();
    QDate startOfLastYear = QDate(currentDate.year() - 1, 1, 1);
    QDate endOfLastYear = QDate(currentDate.year() - 1, 12, 31);
    QSqlQuery query(db);
    query.prepare("SELECT SUM(amount) FROM expense WHERE date BETWEEN :start AND :end AND type = '工资'");
    query.bindValue(":start", startOfLastYear);
    query.bindValue(":end", endOfLastYear);
    query.exec();
    query.next();
    return query.value(0).toDouble();
}
