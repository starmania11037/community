
#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QList>
#include <QVariant>
#include <QSqlError>
#include <QDate>

class DatabaseManager {
public:
    bool open(const QString& dbName);
    void close();
    QList<QVariantList> getComplaints();
    double getIncomeSum(const QString& type);
    double getExpenseSum(const QString& type);
    bool updateComplaintStatus(int id, bool handled);
    void processParkingSpaceData();
    void transferPaymentToIncome();
    void transferAttendanceToExpense();
    double getYesterdayIncome();
    double getYesterdayPropertyFeeIncome();
    double getYesterdayParkingFeeIncome();
    double getLastMonthIncome();
    double getLastMonthPropertyFeeIncome();
    double getLastMonthParkingFeeIncome();
    double getLastYearIncome();
    double getLastYearPropertyFeeIncome();
    double getLastYearParkingFeeIncome();
    double getYesterdayExpense();
    double getYesterdayMaintenanceExpense();
    double getYesterdaySalaryExpense();
    double getLastMonthExpense();
    double getLastMonthMaintenanceExpense();
    double getLastMonthSalaryExpense();
    double getLastYearExpense();
    double getLastYearMaintenanceExpense();
    double getLastYearSalaryExpense();
    QSqlDatabase db; // 保持公有，供外部查询使用
};
#endif // DATABASEMANAGER_H
