
#include "feereportpage.h"
#include <QLabel>
#include <QHeaderView>
#include <QMessageBox>
#include <QFileDialog>

// 修改构造函数
FeeReportPage::FeeReportPage(QWidget *parent) : QWidget(parent) {
    // 标题
    QLabel* titleLabel = new QLabel("费用报表", this);
    titleLabel->setStyleSheet("color: blue; font-size: 24px; font-weight: bold;");
    titleLabel->setAlignment(Qt::AlignCenter);

    // 下拉框选择报表类型
    reportTypeComboBox = new QComboBox(this);
    reportTypeComboBox->addItem("生成收入费用报表");
    reportTypeComboBox->addItem("生成支出费用报表");

    // 表格
    tableView = new QTableView(this);
    tableView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    tableView->horizontalHeader()->setStretchLastSection(true);
    tableView->verticalHeader()->setVisible(false);

    // 按钮
    generateButton = new QPushButton("生成报表", this);
    exportButton = new QPushButton("导出为 PDF", this);

    // 布局
    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setContentsMargins(10, 10, 10, 10);
    layout->addWidget(titleLabel);
    layout->addWidget(reportTypeComboBox); // 添加下拉框到布局
    layout->addWidget(generateButton);
    layout->addWidget(tableView, 1); // 表格占主要空间
    layout->addWidget(exportButton);

    connect(generateButton, &QPushButton::clicked, this, &FeeReportPage::generateReport);
    connect(exportButton, &QPushButton::clicked, this, &FeeReportPage::exportToPDF);
}

FeeReportPage::~FeeReportPage()
{
}

void FeeReportPage::generateReport()
{
    QString reportType = reportTypeComboBox->currentText();
    loadDataFromDatabase(reportType);
}

void FeeReportPage::loadDataFromDatabase(const QString& reportType)
{
    model = new QStandardItemModel(this);
    if (reportType == "生成收入费用报表") {
        model->setColumnCount(5);
        model->setHorizontalHeaderLabels({"id", "日期", "类型", "金额", "备注"});
        if (db.open("income.db")) {
            QSqlQuery query(db.db);
            query.exec("SELECT * FROM income");
            int row = 0;
            while (query.next()) {
                for (int col = 0; col < model->columnCount(); ++col) {
                    model->setItem(row, col, new QStandardItem(query.value(col).toString()));
                }
                ++row;
            }
            db.close();
        }
    } else if (reportType == "生成支出费用报表") {
        model->setColumnCount(4);
        model->setHorizontalHeaderLabels({"id", "日期", "类型", "金额"});
        if (db.open("expense.db")) {
            QSqlQuery query(db.db);
            query.exec("SELECT * FROM expense");
            int row = 0;
            while (query.next()) {
                for (int col = 0; col < model->columnCount(); ++col) {
                    model->setItem(row, col, new QStandardItem(query.value(col).toString()));
                }
                ++row;
            }
            db.close();
        }
    }
    tableView->setModel(model);
}

void FeeReportPage::exportToPDF() {
    // 1. 检查模型是否为空（未生成报表时禁止导出）
    if (!model || model->rowCount() == 0) {
        QMessageBox::warning(this, "警告", "请先生成报表再导出！");
        return;
    }

    // 2. 让用户选择保存路径和文件名
    QString fileName = QFileDialog::getSaveFileName(
        this,
        "导出PDF",
        QString(), // 默认路径（当前目录）
        "PDF文件 (*.pdf)" // 文件过滤
    );

    // 若用户取消选择，直接返回
    if (fileName.isEmpty()) {
        return;
    }

    // 3. 初始化PDF写入器
    QPdfWriter writer(fileName);
    // 设置PDF页面大小（A4）
    writer.setPageSize(QPdfWriter::A4);
    // 设置页面边距
    writer.setPageMargins(QMarginsF(20, 20, 20, 20));



    // 4. 绘制PDF内容
    QPainter painter(&writer);
    if (!painter.isActive()) {
        QMessageBox::critical(this, "错误", "绘制PDF失败！");
        return;
    }

    // 设置字体（支持中文）
    QFont font("SimHei", 12); // 使用黑体，确保中文显示
    painter.setFont(font);

    // 6. 绘制报表标题
    QFont titleFont("SimHei", 16, QFont::Bold);
    painter.setFont(titleFont);
    QString title = reportTypeComboBox->currentText() == "生成收入费用报表"
                    ? "收入费用报表"
                    : "支出费用报表";
    painter.drawText(QRectF(0, 10, writer.width(), 30), Qt::AlignCenter, title);

    // 7. 绘制表头（恢复默认字体）
    painter.setFont(font);
    int headerY = 60; // 表头Y坐标（标题下方）
    int colWidth = (writer.width() - 40) / model->columnCount(); // 平均分配列宽

    for (int col = 0; col < model->columnCount(); ++col) {
        // 绘制表头文本（左对齐，带背景色）
        painter.fillRect(QRectF(20 + col * colWidth, headerY, colWidth, 30), QColor("#f0f0f0"));
        painter.drawText(
            QRectF(20 + col * colWidth, headerY, colWidth, 30),
            Qt::AlignCenter,
            model->headerData(col, Qt::Horizontal).toString()
        );
    }

    // 8. 绘制表格内容
    int contentY = headerY + 35; // 内容Y坐标（表头下方）
    for (int row = 0; row < model->rowCount(); ++row) {
        // 隔行变色（增强可读性）
        if (row % 2 == 1) {
            painter.fillRect(
                QRectF(20, contentY, writer.width() - 40, 25),
                QColor("#f9f9f9")
            );
        }

        // 绘制每行内容
        for (int col = 0; col < model->columnCount(); ++col) {
            QString text = model->item(row, col) ? model->item(row, col)->text() : "";
            painter.drawText(
                QRectF(20 + col * colWidth, contentY, colWidth, 25),
                Qt::AlignCenter,
                text
            );
        }
        contentY += 25; // 下一行Y坐标

        // 超过页面高度时自动分页
        if (contentY + 25 > writer.height() - 20) {
            writer.newPage(); // 新建一页
            contentY = 20; // 重置Y坐标到新页面顶部
        }
    }

    // 9. 完成绘制并提示成功
    painter.end();
    QMessageBox::information(this, "成功", QString("PDF已导出至：\n%1").arg(fileName));
}
