
#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include "summarypage.h"
#include "incomedetailpage.h"
#include "expendituredetailpage.h"
#include "complaintrecordpage.h"
#include "feereportpage.h"

class AdminWindow : public QMainWindow {
    Q_OBJECT
public:
    AdminWindow(QWidget *parent = nullptr);

private slots:
    void showPage(int index);
    void showDailyIncomePage();
    void showMonthlyIncomePage();
    void showYearlyIncomePage();
    void showDailyExpensePage();
    void showMonthlyExpensePage();
    void showYearlyExpensePage();

private:
    QStackedWidget* stackedWidget;
    QPushButton* financeCenterButton;
    QPushButton* userFeedbackButton;
    QPushButton* incomeButton;
    QPushButton* expenditureButton;
    QPushButton* complaintButton;
    QPushButton* feeReportButton;

    QPushButton* dailyIncomeButton;
    QPushButton* monthlyIncomeButton;
    QPushButton* yearlyIncomeButton;
    QPushButton* dailyExpenseButton;
    QPushButton* monthlyExpenseButton;
    QPushButton* yearlyExpenseButton;
    QWidget* dailyIncomePage;
    QWidget* monthlyIncomePage;
    QWidget* yearlyIncomePage;
    QWidget* dailyExpensePage;
    QWidget* monthlyExpensePage;
    QWidget* yearlyExpensePage;
    void executeDbOperationsAndShowPage(int index);
};

#endif // ADMINWINDOW_H
