/********************************************************************************
** Form generated from reading UI file 'yearlyexpensedetailpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_YEARLYEXPENSEDETAILPAGE_H
#define UI_YEARLYEXPENSEDETAILPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_YearlyExpenseDetailPage
{
public:

    void setupUi(QWidget *YearlyExpenseDetailPage)
    {
        if (YearlyExpenseDetailPage->objectName().isEmpty())
            YearlyExpenseDetailPage->setObjectName(QString::fromUtf8("YearlyExpenseDetailPage"));
        YearlyExpenseDetailPage->resize(400, 300);

        retranslateUi(YearlyExpenseDetailPage);

        QMetaObject::connectSlotsByName(YearlyExpenseDetailPage);
    } // setupUi

    void retranslateUi(QWidget *YearlyExpenseDetailPage)
    {
        YearlyExpenseDetailPage->setWindowTitle(QApplication::translate("YearlyExpenseDetailPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class YearlyExpenseDetailPage: public Ui_YearlyExpenseDetailPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_YEARLYEXPENSEDETAILPAGE_H
