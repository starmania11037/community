/********************************************************************************
** Form generated from reading UI file 'expendituredetailpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EXPENDITUREDETAILPAGE_H
#define UI_EXPENDITUREDETAILPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ExpenditureDetailPage
{
public:

    void setupUi(QWidget *ExpenditureDetailPage)
    {
        if (ExpenditureDetailPage->objectName().isEmpty())
            ExpenditureDetailPage->setObjectName(QString::fromUtf8("ExpenditureDetailPage"));
        ExpenditureDetailPage->resize(400, 300);

        retranslateUi(ExpenditureDetailPage);

        QMetaObject::connectSlotsByName(ExpenditureDetailPage);
    } // setupUi

    void retranslateUi(QWidget *ExpenditureDetailPage)
    {
        ExpenditureDetailPage->setWindowTitle(QApplication::translate("ExpenditureDetailPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ExpenditureDetailPage: public Ui_ExpenditureDetailPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EXPENDITUREDETAILPAGE_H
