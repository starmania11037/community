/********************************************************************************
** Form generated from reading UI file 'monthlyexpensedetailpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MONTHLYEXPENSEDETAILPAGE_H
#define UI_MONTHLYEXPENSEDETAILPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MonthlyExpenseDetailPage
{
public:

    void setupUi(QWidget *MonthlyExpenseDetailPage)
    {
        if (MonthlyExpenseDetailPage->objectName().isEmpty())
            MonthlyExpenseDetailPage->setObjectName(QString::fromUtf8("MonthlyExpenseDetailPage"));
        MonthlyExpenseDetailPage->resize(400, 300);

        retranslateUi(MonthlyExpenseDetailPage);

        QMetaObject::connectSlotsByName(MonthlyExpenseDetailPage);
    } // setupUi

    void retranslateUi(QWidget *MonthlyExpenseDetailPage)
    {
        MonthlyExpenseDetailPage->setWindowTitle(QApplication::translate("MonthlyExpenseDetailPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MonthlyExpenseDetailPage: public Ui_MonthlyExpenseDetailPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MONTHLYEXPENSEDETAILPAGE_H
