/********************************************************************************
** Form generated from reading UI file 'monthlyincomedetailpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MONTHLYINCOMEDETAILPAGE_H
#define UI_MONTHLYINCOMEDETAILPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MonthlyIncomeDetailPage
{
public:

    void setupUi(QWidget *MonthlyIncomeDetailPage)
    {
        if (MonthlyIncomeDetailPage->objectName().isEmpty())
            MonthlyIncomeDetailPage->setObjectName(QString::fromUtf8("MonthlyIncomeDetailPage"));
        MonthlyIncomeDetailPage->resize(400, 300);

        retranslateUi(MonthlyIncomeDetailPage);

        QMetaObject::connectSlotsByName(MonthlyIncomeDetailPage);
    } // setupUi

    void retranslateUi(QWidget *MonthlyIncomeDetailPage)
    {
        MonthlyIncomeDetailPage->setWindowTitle(QApplication::translate("MonthlyIncomeDetailPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MonthlyIncomeDetailPage: public Ui_MonthlyIncomeDetailPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MONTHLYINCOMEDETAILPAGE_H
