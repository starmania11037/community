/********************************************************************************
** Form generated from reading UI file 'dailyexpensedetailpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DAILYEXPENSEDETAILPAGE_H
#define UI_DAILYEXPENSEDETAILPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DailyExpenseDetailPage
{
public:

    void setupUi(QWidget *DailyExpenseDetailPage)
    {
        if (DailyExpenseDetailPage->objectName().isEmpty())
            DailyExpenseDetailPage->setObjectName(QString::fromUtf8("DailyExpenseDetailPage"));
        DailyExpenseDetailPage->resize(400, 300);

        retranslateUi(DailyExpenseDetailPage);

        QMetaObject::connectSlotsByName(DailyExpenseDetailPage);
    } // setupUi

    void retranslateUi(QWidget *DailyExpenseDetailPage)
    {
        DailyExpenseDetailPage->setWindowTitle(QApplication::translate("DailyExpenseDetailPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DailyExpenseDetailPage: public Ui_DailyExpenseDetailPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DAILYEXPENSEDETAILPAGE_H
