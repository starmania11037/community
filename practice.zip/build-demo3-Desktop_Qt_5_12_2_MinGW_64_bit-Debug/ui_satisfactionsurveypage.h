/********************************************************************************
** Form generated from reading UI file 'satisfactionsurveypage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SATISFACTIONSURVEYPAGE_H
#define UI_SATISFACTIONSURVEYPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SatisfactionSurveyPage
{
public:

    void setupUi(QWidget *SatisfactionSurveyPage)
    {
        if (SatisfactionSurveyPage->objectName().isEmpty())
            SatisfactionSurveyPage->setObjectName(QString::fromUtf8("SatisfactionSurveyPage"));
        SatisfactionSurveyPage->resize(400, 300);

        retranslateUi(SatisfactionSurveyPage);

        QMetaObject::connectSlotsByName(SatisfactionSurveyPage);
    } // setupUi

    void retranslateUi(QWidget *SatisfactionSurveyPage)
    {
        SatisfactionSurveyPage->setWindowTitle(QApplication::translate("SatisfactionSurveyPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SatisfactionSurveyPage: public Ui_SatisfactionSurveyPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SATISFACTIONSURVEYPAGE_H
