/********************************************************************************
** Form generated from reading UI file 'complaintrecordpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_COMPLAINTRECORDPAGE_H
#define UI_COMPLAINTRECORDPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ComplaintRecordPage
{
public:

    void setupUi(QWidget *ComplaintRecordPage)
    {
        if (ComplaintRecordPage->objectName().isEmpty())
            ComplaintRecordPage->setObjectName(QString::fromUtf8("ComplaintRecordPage"));
        ComplaintRecordPage->resize(400, 300);

        retranslateUi(ComplaintRecordPage);

        QMetaObject::connectSlotsByName(ComplaintRecordPage);
    } // setupUi

    void retranslateUi(QWidget *ComplaintRecordPage)
    {
        ComplaintRecordPage->setWindowTitle(QApplication::translate("ComplaintRecordPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ComplaintRecordPage: public Ui_ComplaintRecordPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COMPLAINTRECORDPAGE_H
