/********************************************************************************
** Form generated from reading UI file 'dailyincomedetailpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DAILYINCOMEDETAILPAGE_H
#define UI_DAILYINCOMEDETAILPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DailyIncomeDetailPage
{
public:

    void setupUi(QWidget *DailyIncomeDetailPage)
    {
        if (DailyIncomeDetailPage->objectName().isEmpty())
            DailyIncomeDetailPage->setObjectName(QString::fromUtf8("DailyIncomeDetailPage"));
        DailyIncomeDetailPage->resize(400, 300);

        retranslateUi(DailyIncomeDetailPage);

        QMetaObject::connectSlotsByName(DailyIncomeDetailPage);
    } // setupUi

    void retranslateUi(QWidget *DailyIncomeDetailPage)
    {
        DailyIncomeDetailPage->setWindowTitle(QApplication::translate("DailyIncomeDetailPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DailyIncomeDetailPage: public Ui_DailyIncomeDetailPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DAILYINCOMEDETAILPAGE_H
