/********************************************************************************
** Form generated from reading UI file 'incomedetailpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INCOMEDETAILPAGE_H
#define UI_INCOMEDETAILPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_IncomeDetailPage
{
public:

    void setupUi(QWidget *IncomeDetailPage)
    {
        if (IncomeDetailPage->objectName().isEmpty())
            IncomeDetailPage->setObjectName(QString::fromUtf8("IncomeDetailPage"));
        IncomeDetailPage->resize(400, 300);

        retranslateUi(IncomeDetailPage);

        QMetaObject::connectSlotsByName(IncomeDetailPage);
    } // setupUi

    void retranslateUi(QWidget *IncomeDetailPage)
    {
        IncomeDetailPage->setWindowTitle(QApplication::translate("IncomeDetailPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class IncomeDetailPage: public Ui_IncomeDetailPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INCOMEDETAILPAGE_H
