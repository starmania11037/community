/********************************************************************************
** Form generated from reading UI file 'feereportpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FEEREPORTPAGE_H
#define UI_FEEREPORTPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FeeReportPage
{
public:

    void setupUi(QWidget *FeeReportPage)
    {
        if (FeeReportPage->objectName().isEmpty())
            FeeReportPage->setObjectName(QString::fromUtf8("FeeReportPage"));
        FeeReportPage->resize(400, 300);

        retranslateUi(FeeReportPage);

        QMetaObject::connectSlotsByName(FeeReportPage);
    } // setupUi

    void retranslateUi(QWidget *FeeReportPage)
    {
        FeeReportPage->setWindowTitle(QApplication::translate("FeeReportPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FeeReportPage: public Ui_FeeReportPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FEEREPORTPAGE_H
