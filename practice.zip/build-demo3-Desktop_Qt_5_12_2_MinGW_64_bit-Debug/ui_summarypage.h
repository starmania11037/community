/********************************************************************************
** Form generated from reading UI file 'summarypage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUMMARYPAGE_H
#define UI_SUMMARYPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SummaryPage
{
public:

    void setupUi(QWidget *SummaryPage)
    {
        if (SummaryPage->objectName().isEmpty())
            SummaryPage->setObjectName(QString::fromUtf8("SummaryPage"));
        SummaryPage->resize(400, 300);

        retranslateUi(SummaryPage);

        QMetaObject::connectSlotsByName(SummaryPage);
    } // setupUi

    void retranslateUi(QWidget *SummaryPage)
    {
        SummaryPage->setWindowTitle(QApplication::translate("SummaryPage", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SummaryPage: public Ui_SummaryPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUMMARYPAGE_H
