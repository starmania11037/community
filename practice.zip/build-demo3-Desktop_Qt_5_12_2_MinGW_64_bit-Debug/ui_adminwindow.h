/********************************************************************************
** Form generated from reading UI file 'adminwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINWINDOW_H
#define UI_ADMINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminWindow
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *AdminWindow)
    {
        if (AdminWindow->objectName().isEmpty())
            AdminWindow->setObjectName(QString::fromUtf8("AdminWindow"));
        AdminWindow->resize(400, 300);
        menuBar = new QMenuBar(AdminWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        AdminWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(AdminWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        AdminWindow->addToolBar(mainToolBar);
        centralWidget = new QWidget(AdminWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        AdminWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(AdminWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        AdminWindow->setStatusBar(statusBar);

        retranslateUi(AdminWindow);

        QMetaObject::connectSlotsByName(AdminWindow);
    } // setupUi

    void retranslateUi(QMainWindow *AdminWindow)
    {
        AdminWindow->setWindowTitle(QApplication::translate("AdminWindow", "AdminWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdminWindow: public Ui_AdminWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINWINDOW_H
