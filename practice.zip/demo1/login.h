#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include "database.h"
#include <QLineEdit>


namespace Ui {
class login;
}

class login : public QDialog
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();

    DataBase db;
    QLineEdit * m_usernameEdit;
    QLineEdit * m_passwordEdit;
    QPushButton * m_loginBtn;
    QPushButton * m_registerBtn;

private slots:
    void onLoginClicked();      //成员函数，槽函数要写明响应,必须写slots
    void onExitClicked();
signals:
    void loginSuccess(int i,int r);
private:
    Ui::login *ui;
};

#endif // LOGIN_H
