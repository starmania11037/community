#include "staffwindow.h"
#include "ui_staffwindow.h"

StaffWindow::StaffWindow(int uid,QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::StaffWindow),
    m_uid(uid)
{
    ui->setupUi(this);

}

StaffWindow::~StaffWindow()
{
    delete ui;
}
