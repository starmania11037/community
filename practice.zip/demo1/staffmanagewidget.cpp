#include "staffmanagewidget.h"
#include "ui_staffmanagewidget.h"

StaffManageWidget::StaffManageWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StaffManageWidget)
{
    ui->setupUi(this);
}

StaffManageWidget::~StaffManageWidget()
{
    delete ui;
}
