#include "carregistrationwidget.h"
#include "ui_carregistrationwidget.h"
#include "database.h"


#include <QHBoxLayout>
#include <QHeaderView>
#include <QLabel>
#include <QSqlQuery>
#include <QDebug>
#include <QLineEdit>
#include <QInputDialog>
#include <QMessageBox>



CarRegistrationWidget::CarRegistrationWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CarRegistrationWidget)
{
    ui->setupUi(this);
    ui->setupUi(this);
    table = new QTableWidget(this);                 //创建表格
    table -> setColumnCount(6);                     //六列
    table -> setHorizontalHeaderLabels({"车主","车牌号","联系电话","车辆颜色","地址","车型",});
    table -> horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);        //表格自动拉伸列宽
    table -> setSelectionBehavior(QAbstractItemView::SelectRows);                   //选中整行
    table -> setEditTriggers(QAbstractItemView::NoEditTriggers);                    //表格不可编辑
    table -> setAlternatingRowColors(true);                                         //交替颜色
    table -> setStyleSheet("QTableWidget{ border:none;background: #f7f7f7;}"
                           "QHeaderView::section{background: #2d5cf0;color:white;font-weight: bold;}"
                           "QTableWidget::item:selection{ background : #cce9ff}");
    //设置外观样式
    btnAdd = new QPushButton("新增",this);
    btnEdit = new QPushButton("编辑",this);
    btnDelete = new QPushButton("删除",this);
    btnConsult = new QPushButton("查询",this);
    //按键美化
    QString btnStyle = "QPushButton {background-color: #2d5cf0;color: white;border-radius:5px; }"
            "QPushButton:hover { background-color: #1a73e4;}";
    btnAdd->setStyleSheet(btnStyle);
    btnEdit->setStyleSheet(btnStyle.replace("#2d5cf0", "#19be6b").replace("#1a73e4", "#13a456"));
    btnDelete->setStyleSheet(btnStyle.replace("#2d5cf0", "#f56c6c").replace("#1a73e4", "#d93028"));
    btnConsult ->setStyleSheet(btnStyle.replace("#2d5cf0", "#f16c6c").replace("#1a73e4", "#d53028"));

    auto* btnLayout = new QHBoxLayout();
    btnLayout->addStretch();
    btnLayout->addWidget(btnAdd);
    btnLayout->addSpacing(15);
    btnLayout->addWidget(btnEdit);
    btnLayout->addSpacing(15);
    btnLayout->addWidget(btnConsult);
    btnLayout->addSpacing(15);
    btnLayout->addWidget(btnDelete);
    btnLayout->addStretch();
    // 标题
    QLabel* title = new QLabel("车辆登记", this);
    title->setAlignment(Qt::AlignCenter);
    QFont font = title->font();
    font.setPointSize(16);
    font.setBold(true);
    title->setFont(font);
    title->setStyleSheet("color: #2d4cf0; margin: 7px;");

    auto* mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(title);
    mainLayout->addLayout(btnLayout);
    mainLayout->addWidget(table);

    connect(btnAdd, &QPushButton::clicked, this, &CarRegistrationWidget::onAdd);
    connect(btnEdit, &QPushButton::clicked, this, &CarRegistrationWidget::onEdit);
    connect(btnDelete, &QPushButton::clicked, this, &CarRegistrationWidget::onDelete);
    refreshTable();

}



void CarRegistrationWidget::refreshTable() {
        table->setRowCount(0);
        DataBase db;
        db.openDB("car.db");

        QString sql = "SELECT carowner, licenseplate,  phone , color, address,type FROM car ";

        QSqlQuery query = db.query(sql,QVariantList());
        int row = 0;
        while (query.next()) {
            table->insertRow(row);
            for (int col = 0; col < 6; ++col) {
                QString val = query.value(col).toString();
                table->setItem(row, col, new QTableWidgetItem(val));
            }
            ++row;
        }
        table->resizeRowsToContents();

}
    void CarRegistrationWidget::onAdd(){
        bool ok;
        QString carowner = QInputDialog::getText(this, "新增车辆", "车主：", QLineEdit::Normal, "", &ok);
        if (!ok || carowner.isEmpty()) return;
        QString type = QInputDialog::getText(this, "新增车辆", "车型：", QLineEdit::Normal, "", &ok);
        if (!ok || type.isEmpty()) return;
        QString licenseplate = QInputDialog::getText(this, "新增车辆", "车牌号", QLineEdit::Normal, "", &ok);
        if (!ok|| licenseplate.isEmpty()) return;
        QString phone = QInputDialog::getText(this, "新增车辆", "手机号：", QLineEdit::Normal, "", &ok);
        if (!ok) return;
        QString address = QInputDialog::getText(this, "新增车辆", "地址：", QLineEdit::Normal, "", &ok);
        if (!ok) return;
        QString color = QInputDialog::getText(this, "新增车辆", "颜色：", QLineEdit::Normal, "", &ok);
        if (!ok) return;

        DataBase db;
        db.openDB("car.db");
        if (!db.openDB("car.db")) {
            QMessageBox::critical(this, "数据库错误", "无法打开数据库文件");
            return;
        }

        QSqlQuery q;
        q.prepare("INSERT INTO car ( carowner,licenseplate,  phone,color,address,type) VALUES (?, ?, ?, ?, ?, ? )");

        q.addBindValue(carowner);
        q.addBindValue(licenseplate);
        q.addBindValue(phone);
        q.addBindValue(color);
        q.addBindValue(address);
        q.addBindValue(type);


        if (!q.exec()) {
            qDebug() << "SQL 执行失败："; // 打印详细错误
            QMessageBox::warning(this, "失败", "添加失败！");
            return;
        } else {
            refreshTable();
        }
    }
    void CarRegistrationWidget::onEdit() {
        QList<QTableWidgetItem*> selectedItems = table->selectedItems();
        if (selectedItems.isEmpty()) {
            QMessageBox::warning(this, "警告", "请先选择要编辑的车辆！");
            return;
        }

        int row = selectedItems.first()->row();
        QString carowner = table->item(row, 0)->text();
        QString licenseplate = table->item(row, 1)->text();
        QString phone = table->item(row, 2)->text();
        QString color = table->item(row, 3)->text();
        QString address = table->item(row, 4)->text();
        QString type = table->item(row, 5)->text();


        bool ok;
        QString newcarOwner = QInputDialog::getText(this, "编辑车辆信息", "车主：", QLineEdit::Normal, carowner, &ok);
        if (!ok) return;

        QString newlicenseplate = QInputDialog::getText(this, "编辑车辆信息", "车牌号：", QLineEdit::Normal, licenseplate , &ok);
        if (!ok) return;


        QString newPhone = QInputDialog::getText(this, "编辑车辆信息", "联系电话：", QLineEdit::Normal, phone, &ok);
        if (!ok) return;

        QString newcolor = QInputDialog::getText(this, "编辑车辆信息", "颜色：", QLineEdit::Normal, color , &ok);
        if (!ok) return;

        QString newAddress = QInputDialog::getText(this, "编辑车辆信息", "地址：", QLineEdit::Normal, address, &ok);
        if (!ok) return;

        QString newtype = QInputDialog::getText(this, "编辑车辆信息", "型号：", QLineEdit::Normal, type , &ok);
        if (!ok) return;


        DataBase db;
        if (!db.openDB("car.db")) {
            QMessageBox::critical(this, "数据库错误", "无法打开数据库文件");
            return;
        }

        QSqlQuery q;
        q.prepare("UPDATE car SET carowner = :carowner,licenseplate = :licenseplate, color = :color, type = :type, phone = :phone, address = :address WHERE carowner = :carowner " );
        q.bindValue(":carowner", newcarOwner);
        q.bindValue(":licenseplate", newlicenseplate);
        q.bindValue(":color", newcolor);
        q.bindValue(":phone", newPhone);
        q.bindValue(":address", newAddress);
        q.bindValue(":type", newtype);

        if (!q.exec()) {
            qDebug() << "更新失败：";
            QMessageBox::critical(this, "错误", "更新过程中出现错误！");
            return;
        }

        refreshTable();
        QMessageBox::information(this, "成功", "车辆信息更新成功！");
    }

    void CarRegistrationWidget::onDelete() {
        QList<QTableWidgetItem*> selectedItems = table->selectedItems();
        if (selectedItems.isEmpty()) {
            QMessageBox::warning(this, "警告", "请先选择要删除的车辆！");
            return;
        }

        QSet<int> selectedRows;
        for (auto item : selectedItems) {
            selectedRows.insert(item->row());
        }

        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "确认删除",
                                     QString("确定要删除选中的 %1 个车辆吗？此操作不可撤销！").arg(selectedRows.size()),
                                     QMessageBox::Yes | QMessageBox::No);
        if (reply != QMessageBox::Yes) return;

        DataBase db;
        if (!db.openDB("car.db")) {
            QMessageBox::critical(this, "数据库错误", "无法打开数据库文件");
            return;
        }

        QSqlQuery q;
        q.prepare("DELETE FROM car WHERE id = :id");

        for (int row : selectedRows) {
            int id = table->item(row, 0)->text().toInt();
            q.bindValue(":id", id);
            if (!q.exec()) {
                qDebug() << "删除失败：" ;
                QMessageBox::critical(this, "错误", "删除过程中出现错误！");
                return;
            }
        }

        refreshTable();
        QMessageBox::information(this, "成功", "车辆删除成功！");
    }

CarRegistrationWidget::~CarRegistrationWidget()
{
    delete ui;
}
