#ifndef STAFFMANAGEWIDGET_H
#define STAFFMANAGEWIDGET_H

#include <QWidget>

namespace Ui {
class StaffManageWidget;
}

class StaffManageWidget : public QWidget
{
    Q_OBJECT

public:
    explicit StaffManageWidget(QWidget *parent = nullptr);
    ~StaffManageWidget();

private:
    Ui::StaffManageWidget *ui;
};

#endif // STAFFMANAGEWIDGET_H
