#include "smtcontrolwidget.h"
#include "ui_smtcontrolwidget.h"

SmtControlWidget::SmtControlWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SmtControlWidget)
{
    ui->setupUi(this);
}

SmtControlWidget::~SmtControlWidget()
{
    delete ui;
}
