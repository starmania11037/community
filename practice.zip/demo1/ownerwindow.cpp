
#include "ownerwindow.h"
#include "ui_ownerwindow.h"
#include "familymemberwidget.h"
#include "carregistrationwidget.h"
#include "smtcontrolwidget.h"
#include "publicitywidget.h"
#include "noticewidget.h"
#include "warningwidget.h"
#include "initiativewidget.h"
#include "databasehelper.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QTreeWidgetItem>
#include <QDateTime>
#include <QMessageBox>
#include <QDebug>
#include <QSqlError>

OwnerWindow::OwnerWindow(int id, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::OwnerWindow),
    m_uid(id)
{
    ui->setupUi(this);
    setWindowTitle("业主中心");

    // 打开公告数据库
    if (!m_db.openDB("announcement.db")) {
        QMessageBox::critical(this, "数据库错误", "无法打开公告数据库！");
    }

    // 初始化组件（含公告列表控件）
    m_familyWidget = new FamilyMemberWidget(this);
    m_carWidget = new CarRegistrationWidget(this);
    m_smtWidget = new SmtControlWidget(this);
    m_noticeWidget = new NoticeWidget(this);
    m_publicityWidget = new PublicityWidget(this);
    m_warningWidget = new WarningWidget(this);
    m_initiativeWidget = new InitiativeWidget(this);

    // 初始化公告列表控件（关键修改：在OwnerWindow中创建并绑定到子页面）
    m_noticeList = new QListWidget(m_noticeWidget);
    m_publicityList = new QListWidget(m_publicityWidget);
    m_warningList = new QListWidget(m_warningWidget);
    m_initiativeList = new QListWidget(m_initiativeWidget);

    // 为子页面设置布局（将列表控件嵌入子页面）
    m_noticeWidget->setLayout(new QVBoxLayout());
    m_noticeWidget->layout()->addWidget(m_noticeList);
    m_publicityWidget->setLayout(new QVBoxLayout());
    m_publicityWidget->layout()->addWidget(m_publicityList);
    m_warningWidget->setLayout(new QVBoxLayout());
    m_warningWidget->layout()->addWidget(m_warningList);
    m_initiativeWidget->setLayout(new QVBoxLayout());
    m_initiativeWidget->layout()->addWidget(m_initiativeList);

    // 美化列表控件
    QList<QListWidget*> allLists = {m_noticeList, m_publicityList, m_warningList, m_initiativeList};
    for (QListWidget* list : allLists) {
        list->setStyleSheet(
            "QListWidget { border: 1px solid #eee; border-radius: 4px; padding: 8px; }"
            "QListWidget::item { padding: 6px; margin: 2px 0; border-bottom: 1px solid #f5f5f5; }"
            "QListWidget::item:hover { background-color: #f0f7ff; }"
        );
    }

    initLayout();
    initStatusBar();
    connectSignals();

    // 默认选中"我的家园"
    m_mainNavList->setCurrentRow(0);

}

OwnerWindow::~OwnerWindow()
{
    delete ui;
}

// 初始化布局
void OwnerWindow::initLayout()
{
    // 中央部件与主布局
    QWidget* centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    QHBoxLayout* mainLayout = new QHBoxLayout(centralWidget);
    mainLayout->setSpacing(0);
    mainLayout->setContentsMargins(0, 0, 0, 0);

    // 左侧主导航
    m_mainNavList = new QListWidget(this);
    m_mainNavList->setFixedWidth(180);
    m_mainNavList->addItem("我的家园");
    m_mainNavList->addItem("公告");
    m_mainNavList->setStyleSheet(
        "QListWidget { background-color: #f0f0f0; border-right: 1px solid #ddd; }"
        "QListWidget::item { height: 50px; font-size: 14px; padding-left: 20px; }"
        "QListWidget::item:selected { background-color: #4a86e8; color: white; }"
    );

    // 主内容区域
    m_mainContentStack = new QStackedWidget(this);

    // "我的家园"页面（保持不变）
    QWidget* homePage = new QWidget(this);
    QHBoxLayout* homeLayout = new QHBoxLayout(homePage);
    homeLayout->setSpacing(0);
    homeLayout->setContentsMargins(0, 0, 0, 0);

    m_homeSubNav = new QTreeWidget(this);
    m_homeSubNav->setFixedWidth(160);
    m_homeSubNav->setHeaderHidden(true);
    m_homeSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "家庭成员维护"));
    m_homeSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "车辆登记"));
    m_homeSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "智能控制"));
    m_homeSubNav->setStyleSheet(
        "QTreeWidget { background-color: #fafafa; border-right: 1px solid #eee; }"
        "QTreeWidget::item { height: 40px; font-size: 13px; }"
        "QTreeWidget::item:selected { background-color: #e6f7ff; color: #1890ff; }"
    );

    m_homeContentStack = new QStackedWidget(this);
    m_homeContentStack->addWidget(m_familyWidget);
    m_homeContentStack->addWidget(m_carWidget);
    m_homeContentStack->addWidget(m_smtWidget);
    homeLayout->addWidget(m_homeSubNav);
    homeLayout->addWidget(m_homeContentStack, 1);

    // "公告"页面（核心：绑定子页面与列表控件）
    QWidget* announcementPage = new QWidget(this);
    QHBoxLayout* announcementLayout = new QHBoxLayout(announcementPage);
    announcementLayout->setSpacing(0);
    announcementLayout->setContentsMargins(0, 0, 0, 0);

    m_announcementSubNav = new QTreeWidget(this);
    m_announcementSubNav->setFixedWidth(160);
    m_announcementSubNav->setHeaderHidden(true);
    m_announcementSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "通知"));
    m_announcementSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "公示"));
    m_announcementSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "警示"));
    m_announcementSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "倡议"));
    m_announcementSubNav->setStyleSheet(m_homeSubNav->styleSheet());

    m_announcementContentStack = new QStackedWidget(this);
    m_announcementContentStack->addWidget(m_noticeWidget);      // 通知页面（绑定m_noticeList）
    m_announcementContentStack->addWidget(m_publicityWidget);   // 公示页面（绑定m_publicityList）
    m_announcementContentStack->addWidget(m_warningWidget);     // 警示页面（绑定m_warningList）
    m_announcementContentStack->addWidget(m_initiativeWidget);  // 倡议页面（绑定m_initiativeList）
    announcementLayout->addWidget(m_announcementSubNav);
    announcementLayout->addWidget(m_announcementContentStack, 1);

    // 组装主布局
    m_mainContentStack->addWidget(homePage);
    m_mainContentStack->addWidget(announcementPage);
    mainLayout->addWidget(m_mainNavList);
    mainLayout->addWidget(m_mainContentStack, 1);

    // 预加载"通知"公告
    m_announcementContentStack->setCurrentIndex(0);
    loadAnnouncements("通知");
}

// 初始化状态栏（保持不变）
void OwnerWindow::initStatusBar()
{
    m_userLabel = new QLabel(QString("当前用户：业主 ID=%1").arg(m_uid), this);
    m_timeLabel = new QLabel(this);
    m_timer = new QTimer(this);
    ui->statusbar->addPermanentWidget(m_userLabel, 1);
    ui->statusbar->addPermanentWidget(m_timeLabel, 1);
    updateTime();
}

void OwnerWindow::loadAnnouncements(const QString& type) {
    QListWidget* targetList = nullptr;
    // 匹配公告类型到列表控件（确保正确）
    if (type == "通知") targetList = m_noticeList;
    else if (type == "公示") targetList = m_publicityList;
    else if (type == "警示") targetList = m_warningList;
    else if (type == "倡议") targetList = m_initiativeList;

    if (!targetList) return;
    targetList->clear();

    QSqlDatabase db = DatabaseHelper::getDatabase();
    QSqlQuery query(db);
    query.prepare("SELECT content, creator, created_at FROM announcements WHERE type = ? ORDER BY created_at DESC");
    query.bindValue(0, type); // 显式绑定参数（唯一占位符）

    if (!query.exec()) {
        targetList->addItem("DB Error: " + query.lastError().text());
        qDebug() << "SQL Query:" << query.lastQuery();
        qDebug() << "DB Error:" << query.lastError().text();
        return;
    }

    while (query.next()) {
        QString content = query.value(0).toString();
        QString creator = query.value(1).toString();
        QString time = query.value(2).toString();
        QDateTime dt = QDateTime::fromString(time, "yyyy-MM-dd HH:mm:ss");
        if (!dt.isValid()) dt = QDateTime::fromString(time, Qt::ISODate);

        targetList->addItem(
            QString("[%1] 发布者: %2 时间: %3\n内容: %4")
            .arg(type)
            .arg(creator)
            .arg(dt.toString("yyyy-MM-dd HH:mm"))
            .arg(content)
        );
    }
}

// 连接信号槽（保持不变）
void OwnerWindow::connectSignals()
{
    connect(m_mainNavList, &QListWidget::currentRowChanged,
            this, &OwnerWindow::onMainNavChanged);
    connect(m_homeSubNav, &QTreeWidget::itemClicked,
            this, &OwnerWindow::onHomeSubNavClicked);
    connect(m_announcementSubNav, &QTreeWidget::itemClicked,
            this, &OwnerWindow::onAnnouncementSubNavClicked);
    connect(m_timer, &QTimer::timeout, this, &OwnerWindow::updateTime);
    m_timer->start(1000);
}

// 主导航切换（保持不变）
void OwnerWindow::onMainNavChanged(int index)
{
    if (index >= 0 && index < m_mainContentStack->count()) {
        m_mainContentStack->setCurrentIndex(index);
    }
}

// "我的家园"子导航切换（保持不变）
void OwnerWindow::onHomeSubNavClicked(QTreeWidgetItem* item, int column)
{
    int index = m_homeSubNav->indexOfTopLevelItem(item);
    if (index >= 0 && index < m_homeContentStack->count()) {
        m_homeContentStack->setCurrentIndex(index);
    }
}

// "公告"子导航切换（保持不变）
void OwnerWindow::onAnnouncementSubNavClicked(QTreeWidgetItem* item, int column)
{
    int index = m_announcementSubNav->indexOfTopLevelItem(item);
    if (index >= 0 && index < m_announcementContentStack->count()) {
        m_announcementContentStack->setCurrentIndex(index);

        // 加载对应类型公告
        QString type;
        switch (index) {
        case 0: type = "通知"; break;
        case 1: type = "公示"; break;
        case 2: type = "警示"; break;
        case 3: type = "倡议"; break;
        default: return;
        }
        loadAnnouncements(type);
    }
}

void OwnerWindow::updateTime(){
    m_timeLabel->setText(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss"));
}
