#ifndef LEAVEAPPROVEWIDGET_H
#define LEAVEAPPROVEWIDGET_H

#include <QWidget>
#include <QTableWidget>
#include <QPushButton>

namespace Ui {
class LeaveApproveWidget;
}

class LeaveApproveWidget : public QWidget
{
    Q_OBJECT

public:
    explicit LeaveApproveWidget(QWidget *parent = nullptr);
    ~LeaveApproveWidget();
 private slots:
    void onApprove();
    void onReject();
    void refreshTable();

private:
    QTableWidget* table;
    QPushButton* btnApprove;
    QPushButton* btnReject;
void loadLeaves();

private:
    Ui::LeaveApproveWidget *ui;
};

#endif // LEAVEAPPROVEWIDGET_H
