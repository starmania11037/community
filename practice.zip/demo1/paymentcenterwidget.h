#ifndef PAYMENTCENTER_H
#define PAYMENTCENTER_H

#include <QWidget>

namespace Ui {
class PaymentCenter;
}

class PaymentCenter : public QWidget
{
    Q_OBJECT

public:
    explicit PaymentCenter(QWidget *parent = nullptr);
    ~PaymentCenter();

    Ui::PaymentCenter *ui;
};

#endif // PAYMENTCENTER_H
