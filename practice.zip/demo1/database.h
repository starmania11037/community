#ifndef DATEBASE_H
#define DATEBASE_H
#include <QObject>
#include <QMap>
#include <QSqlDatabase>
#include <QSqlQuery>



class DataBase : public QObject
{
public:
    DataBase();
    ~DataBase();
    QSqlQuery query(const QString& sql, const QVariantList& args);
    bool openDB (const QString & dbPath);
   public:
    QSqlQuery getUserByUsername(const QString& username);
private :
    QSqlDatabase m_db;
};
#endif // DATEBASE_H
