#ifndef SMTCONTROLWIDGET_H
#define SMTCONTROLWIDGET_H

#include <QWidget>

namespace Ui {
class SmtControlWidget;
}

class SmtControlWidget : public QWidget
{
    Q_OBJECT

public:
    explicit SmtControlWidget(QWidget *parent = nullptr);
    ~SmtControlWidget();

private:
    Ui::SmtControlWidget *ui;
};

#endif // SMTCONTROLWIDGET_H
