#include "announcementwidget.h"
#include "ui_announcementwidget.h"

AnnouncementWidget::AnnouncementWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AnnouncementWidget)
{
    ui->setupUi(this);
}

AnnouncementWidget::~AnnouncementWidget()
{
    delete ui;
}
