#ifndef FAMILYMEMBERWIDGET_H
#define FAMILYMEMBERWIDGET_H

#include <QWidget>
#include <QTableWidget>
#include <QPushButton>


namespace Ui {
class FamilyMemberWidget;
}

class FamilyMemberWidget : public QWidget
{
    Q_OBJECT
public:
    explicit FamilyMemberWidget(QWidget *parent = nullptr);
    ~FamilyMemberWidget();

private:
    Ui::FamilyMemberWidget *ui;
    QTableWidget* table;
    QPushButton* btnAdd;
    QPushButton* btnEdit;
    QPushButton* btnDelete;
    QPushButton* btnConsult;
    void onAdd();
    void onEdit();
    void onDelete();
    void onConsult();

private slots:
    void refreshTable();
};


#endif // FAMILYMEMBERWIDGET_H
