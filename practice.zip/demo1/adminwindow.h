
#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H
#include <QMainWindow>
#include <QStackedWidget>
#include <QListWidget>
#include <QTreeWidget>
#include "announcementwindow.h"

namespace Ui {
class AdminWindow;
}

class AdminWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit AdminWindow(int userId, const QString& userName, QWidget* parent = nullptr);  // 接收用户名
    ~AdminWindow();

private slots:
    void onMainNavChanged(int index);
    void onAnnouncementSubNavClicked(QTreeWidgetItem* item, int column);

private:
    Ui::AdminWindow* ui;
    int m_uid;  // 管理员ID
    QString m_userName;  // 管理员名称

    // 导航组件
    QListWidget* m_mainNavList;
    QStackedWidget* m_mainContentStack;

    // 公告相关组件
    QWidget* m_announcementPage;
    QTreeWidget* m_announcementSubNav;
    QStackedWidget* m_announcementContentStack;
    AnnouncementWindow* m_noticeWindow;
    AnnouncementWindow* m_publicityWindow;
    AnnouncementWindow* m_warningWindow;
    AnnouncementWindow* m_initiativeWindow;

    void initLayout();
};
#endif // ADMINWINDOW_H
