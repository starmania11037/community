
#include "adminwindow.h"
#include "ui_adminwindow.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QTreeWidgetItem>
#include <QMessageBox>

// 构造函数：接收管理员ID和名称
AdminWindow::AdminWindow(int id, const QString& userName, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AdminWindow),
    m_uid(id),
    m_userName(userName)
{
    ui->setupUi(this);
    setWindowTitle("管理员中心");
    initLayout();
}

AdminWindow::~AdminWindow()
{
    delete ui;
}

void AdminWindow::initLayout()
{
    // 1. 中央部件与主布局
    QWidget* centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    QHBoxLayout* mainLayout = new QHBoxLayout(centralWidget);
    mainLayout->setSpacing(0);
    mainLayout->setContentsMargins(0, 0, 0, 0);

    // 2. 左侧主导航
    m_mainNavList = new QListWidget(this);
    m_mainNavList->setFixedWidth(180);
    m_mainNavList->addItem("公告管理");
    m_mainNavList->setStyleSheet(
        "QListWidget { background-color: #f0f0f0; border-right: 1px solid #ddd; }"
        "QListWidget::item { height: 50px; font-size: 14px; padding-left: 20px; }"
        "QListWidget::item:selected { background-color: #4a86e8; color: white; }"
    );

    // 3. 主内容区域
    m_mainContentStack = new QStackedWidget(this);

    // 4. 公告管理页面
    m_announcementPage = new QWidget(this);
    QHBoxLayout* announcementLayout = new QHBoxLayout(m_announcementPage);
    announcementLayout->setSpacing(0);
    announcementLayout->setContentsMargins(0, 0, 0, 0);

    // 4.1 公告子导航
    m_announcementSubNav = new QTreeWidget(this);
    m_announcementSubNav->setFixedWidth(160);
    m_announcementSubNav->setHeaderHidden(true);
    m_announcementSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "通知"));
    m_announcementSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "公示"));
    m_announcementSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "警示"));
    m_announcementSubNav->addTopLevelItem(new QTreeWidgetItem(QStringList() << "倡议"));
    m_announcementSubNav->setStyleSheet(
        "QTreeWidget { background-color: #fafafa; border-right: 1px solid #eee; }"
        "QTreeWidget::item { height: 40px; font-size: 13px; }"
        "QTreeWidget::item:selected { background-color: #e6f7ff; color: #1890ff; }"
    );

    // 4.2 公告内容区域（传入管理员信息）
    m_announcementContentStack = new QStackedWidget(this);
    m_noticeWindow = new AnnouncementWindow(m_uid, m_userName, this);  // 传递ID和名称
    m_publicityWindow = new AnnouncementWindow(m_uid, m_userName, this);
    m_warningWindow = new AnnouncementWindow(m_uid, m_userName, this);
    m_initiativeWindow = new AnnouncementWindow(m_uid, m_userName, this);
    m_announcementContentStack->addWidget(m_noticeWindow);
    m_announcementContentStack->addWidget(m_publicityWindow);
    m_announcementContentStack->addWidget(m_warningWindow);
    m_announcementContentStack->addWidget(m_initiativeWindow);

    // 组装公告页面
    announcementLayout->addWidget(m_announcementSubNav);
    announcementLayout->addWidget(m_announcementContentStack, 1);

    // 添加页面到主内容区域
    m_mainContentStack->addWidget(m_announcementPage);

    // 组装主布局
    mainLayout->addWidget(m_mainNavList);
    mainLayout->addWidget(m_mainContentStack, 1);

    // 信号槽连接
    connect(m_mainNavList, &QListWidget::currentRowChanged, this, &AdminWindow::onMainNavChanged);
    connect(m_announcementSubNav, &QTreeWidget::itemClicked, this, &AdminWindow::onAnnouncementSubNavClicked);

    // 默认选中第一个导航项
    m_mainNavList->setCurrentRow(0);
    m_announcementSubNav->setCurrentItem(m_announcementSubNav->topLevelItem(0));
}

void AdminWindow::onMainNavChanged(int index)
{
    m_mainContentStack->setCurrentIndex(index);
}

void AdminWindow::onAnnouncementSubNavClicked(QTreeWidgetItem* item, int column)
{
    int index = m_announcementSubNav->indexOfTopLevelItem(item);
    if (index >= 0 && index < m_announcementContentStack->count()) {
        m_announcementContentStack->setCurrentIndex(index);
        // 加载对应类型的公告
        switch (index) {
        case 0: m_noticeWindow->loadNotifications(); break;
        case 1: m_publicityWindow->loadPublicity(); break;
        case 2: m_warningWindow->loadWarnings(); break;
        case 3: m_initiativeWindow->loadInitiatives(); break;
        }
    }
}
