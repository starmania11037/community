#include "familymemberwidget.h"
#include "ui_familymemberwidget.h"
#include "database.h"
#include "familymemberwidget.h"

#include <QHBoxLayout>
#include <QHeaderView>
#include <QLabel>
#include <QSqlQuery>
#include <QDebug>
#include <QLineEdit>
#include <QInputDialog>
#include <QMessageBox>


FamilyMemberWidget::FamilyMemberWidget(QWidget *parent) :
    QWidget(parent)
{
    ui->setupUi(this);
    table = new QTableWidget(this);                 //创建表格
    table -> setColumnCount(6);                     //六列
    table -> setHorizontalHeaderLabels({"id","用户名","姓名","角色","联系电话","邮箱地址"});
    table -> horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);        //表格自动拉伸列宽
    table -> setSelectionBehavior(QAbstractItemView::SelectRows);                   //选中整行
    table -> setEditTriggers(QAbstractItemView::NoEditTriggers);                    //表格不可编辑
    table -> setAlternatingRowColors(true);                                         //交替颜色
    table -> setStyleSheet("QTableWidget{ border:none;background: #f7f7f7;}"
                           "QHeaderView::section{background: #2d5cf0;color:white;font-weight: bold;}"
                           "QTableWidget::item:selection{ background : #cce9ff}");
    //设置外观样式
    btnAdd = new QPushButton("新增",this);
    btnEdit = new QPushButton("编辑",this);
    btnDelete = new QPushButton("删除",this);
    btnConsult = new QPushButton("查询",this);
    //按键美化
    QString btnStyle = "QPushButton {background-color: #2d5cf0;color: white;border-radius:5px; }"
            "QPushButton:hover { background-color: #1a73e4;}";
    btnAdd->setStyleSheet(btnStyle);
    btnEdit->setStyleSheet(btnStyle.replace("#2d5cf0", "#19be6b").replace("#1a73e4", "#13a456"));
    btnDelete->setStyleSheet(btnStyle.replace("#2d5cf0", "#f56c6c").replace("#1a73e4", "#d93028"));
    btnConsult ->setStyleSheet(btnStyle.replace("#2d5cf0", "#f16c6c").replace("#1a73e4", "#d53028"));

    auto* btnLayout = new QHBoxLayout();
    btnLayout->addStretch();
    btnLayout->addWidget(btnAdd);
    btnLayout->addSpacing(15);
    btnLayout->addWidget(btnEdit);
    btnLayout->addSpacing(15);
    btnLayout->addWidget(btnConsult);
    btnLayout->addSpacing(15);
    btnLayout->addWidget(btnDelete);
    btnLayout->addStretch();
    // 标题
    QLabel* title = new QLabel("家庭成员管理", this);
    title->setAlignment(Qt::AlignCenter);
    QFont font = title->font();
    font.setPointSize(16);
    font.setBold(true);
    title->setFont(font);
    title->setStyleSheet("color: #2d4cf0; margin: 7px;");

    auto* mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(title);
    mainLayout->addLayout(btnLayout);
    mainLayout->addWidget(table);

    connect(btnAdd, &QPushButton::clicked, this, &FamilyMemberWidget::onAdd);
    connect(btnEdit, &QPushButton::clicked, this, &FamilyMemberWidget::onEdit);
    connect(btnDelete, &QPushButton::clicked, this, &FamilyMemberWidget::onDelete);
    connect(btnConsult, &QPushButton::clicked, this, &FamilyMemberWidget::onConsult);
    refreshTable();
   }
FamilyMemberWidget::~FamilyMemberWidget()
{
    delete ui;
}
void FamilyMemberWidget::refreshTable() {
        table->setRowCount(0);
        DataBase db;
//        db.openDB("user.db");
        db.openDB("family.db");

        QString sql = "SELECT id,username, password, role, phone,address FROM family WHERE role = 2";

        QSqlQuery query = db.query(sql,QVariantList());
        int row = 0;
        while (query.next()) {
            table->insertRow(row);
            for (int col = 0; col < 6; ++col) {
                QString val = query.value(col).toString();
                if (col == 3) { // 状态
                    if (val == "0") val = "管理员";
                    else if (val == "1") val = "物业工作者";
                    else if(val == "2") val = "业主";
                    else val = "未知用户";
                }
                table->setItem(row, col, new QTableWidgetItem(val));
            }
            ++row;
        }
        table->resizeRowsToContents();

}
    void FamilyMemberWidget::onAdd(){
        bool ok;
        QString username = QInputDialog::getText(this, "新增家庭人员", "用户名：", QLineEdit::Normal, "", &ok);
        if (!ok || username.isEmpty()) return;
        QString password = QInputDialog::getText(this, "新增家庭人员", "密码：", QLineEdit::Normal, "", &ok);
        if (!ok || password.isEmpty()) return;
        QString role = QInputDialog::getText(this, "新增家庭人员", "角色", QLineEdit::Normal, "", &ok);
        if (!ok) return;
        QString phone = QInputDialog::getText(this, "新增家庭人员", "手机号：", QLineEdit::Normal, "", &ok);
        if (!ok) return;
        QString address = QInputDialog::getText(this, "新增家庭人员", "地址：", QLineEdit::Normal, "", &ok);
        if (!ok) return;

        DataBase db;
        db.openDB("family.db");
        if (!db.openDB("family.db")) {
            QMessageBox::critical(this, "数据库错误", "无法打开数据库文件");
            return;
        }

        QSqlQuery q;
        q.prepare("INSERT INTO family (username, password, role,phone, address) VALUES (?, ?, ?, ?, ?)");
        q.addBindValue(username);
        q.addBindValue(password);
        q.addBindValue(role); // role
        q.addBindValue(phone);
        q.addBindValue(address);
        if (!q.exec()) {
            qDebug() << "SQL 执行失败："; // 打印详细错误
            QMessageBox::warning(this, "失败", "添加账号失败，用户名可能已存在！");
            return;
        } else {
            refreshTable();
        }
    }
    void FamilyMemberWidget::onEdit() {
        QList<QTableWidgetItem*> selectedItems = table->selectedItems();
        if (selectedItems.isEmpty()) {
            QMessageBox::warning(this, "警告", "请先选择要编辑的家庭成员！");
            return;
        }

        int row = selectedItems.first()->row();
        int id = table->item(row, 0)->text().toInt();
        QString username = table->item(row, 1)->text();
        QString password = table->item(row, 2)->text();
        QString role = table->item(row, 3)->text();
        QString phone = table->item(row, 4)->text();
        QString address = table->item(row, 5)->text();

        // 将角色文本转回数字值
        int roleValue = 2; // 默认业主
        if (role == "管理员") roleValue = 0;
        else if (role == "物业工作者") roleValue = 1;
        else if (role == "业主") roleValue = 2;

        bool ok;
        QString newUsername = QInputDialog::getText(this, "编辑家庭成员", "用户名：", QLineEdit::Normal, username, &ok);
        if (!ok) return;

        QString newPassword = QInputDialog::getText(this, "编辑家庭成员", "密码：", QLineEdit::Password, password, &ok);
        if (!ok) return;



        QStringList roleOptions;
        roleOptions << "管理员" << "物业工作者" << "业主";
        roleValue = roleOptions.indexOf(role); // 初始化当前角色索引（原代码中role是字符串，如"管理员"）

        QString selectedRole = QInputDialog::getItem(this, "编辑家庭成员", "角色：", roleOptions, roleValue, false, &ok);
        if (!ok) return;
        int newRoleIndex = roleOptions.indexOf(selectedRole); // 正确转换为索引

        QString newRole = roleOptions[newRoleIndex];
        int newRoleValue = newRoleIndex; // 后续数据库操作使用索引值

        QString newPhone = QInputDialog::getText(this, "编辑家庭成员", "联系电话：", QLineEdit::Normal, phone, &ok);
        if (!ok) return;

        QString newAddress = QInputDialog::getText(this, "编辑家庭成员", "地址：", QLineEdit::Normal, address, &ok);
        if (!ok) return;

        DataBase db;
        if (!db.openDB("family.db")) {
            QMessageBox::critical(this, "数据库错误", "无法打开数据库文件");
            return;
        }

        QSqlQuery q;
        q.prepare("UPDATE family SET username = :username, password = :password, role = :role, phone = :phone, address = :address WHERE id = :id");
        q.bindValue(":username", newUsername);
        q.bindValue(":password", newPassword);
        q.bindValue(":role", newRoleValue);
        q.bindValue(":phone", newPhone);
        q.bindValue(":address", newAddress);
        q.bindValue(":id", id);

        if (!q.exec()) {
            qDebug() << "更新失败：";
            QMessageBox::critical(this, "错误", "更新过程中出现错误！");
            return;
        }

        refreshTable();
        QMessageBox::information(this, "成功", "家庭成员信息更新成功！");
    }

    void FamilyMemberWidget::onDelete() {
        QList<QTableWidgetItem*> selectedItems = table->selectedItems();
        if (selectedItems.isEmpty()) {
            QMessageBox::warning(this, "警告", "请先选择要删除的家庭成员！");
            return;
        }

        QSet<int> selectedRows;
        for (auto item : selectedItems) {
            selectedRows.insert(item->row());
        }

        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "确认删除",
                                     QString("确定要删除选中的 %1 个家庭成员吗？此操作不可撤销！").arg(selectedRows.size()),
                                     QMessageBox::Yes | QMessageBox::No);
        if (reply != QMessageBox::Yes) return;

        DataBase db;
        if (!db.openDB("family.db")) {
            QMessageBox::critical(this, "数据库错误", "无法打开数据库文件");
            return;
        }

        QSqlQuery q;
        q.prepare("DELETE FROM family WHERE id = :id");

        for (int row : selectedRows) {
            int id = table->item(row, 0)->text().toInt();
            q.bindValue(":id", id);
            if (!q.exec()) {
                qDebug() << "删除失败：" ;
                QMessageBox::critical(this, "错误", "删除过程中出现错误！");
                return;
            }
        }

        refreshTable();
        QMessageBox::information(this, "成功", "家庭成员删除成功！");
    }

    void FamilyMemberWidget::onConsult() {
        QList<QTableWidgetItem*> selectedItems = table->selectedItems();
        if (selectedItems.isEmpty()) {
            QMessageBox::warning(this, "警告", "请先选择要查看的家庭成员！");
            return;
        }

        if (selectedItems.size() < table->columnCount()) {
            QMessageBox::warning(this, "警告", "请完整选择一行数据进行查看！");
            return;
        }

        int row = selectedItems.first()->row();
        QString username = table->item(row, 1)->text();
        QString password = table->item(row, 2)->text();
        QString role = table->item(row, 3)->text();
        QString phone = table->item(row, 4)->text();
        QString address = table->item(row, 5)->text();

        QString info = QString("用户名：%1\n密码：%2\n角色：%3\n联系电话：%4\n地址：%5")
                      .arg(username).arg(password).arg(role).arg(phone).arg(address);

        QMessageBox::information(this, "家庭成员信息", info);
    }
