
#include "mainwindow.h"
#include "adminwindow.h"
#include "staffwindow.h"
#include "ownerwindow.h"
#include "login.h"
#include <QApplication>
#include <QMessageBox>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    login l;

    int uid = -1;
    int role = -1;
    QString userName;  // 存储管理员用户名

    // 登录成功时获取用户ID、角色和用户名
    QObject::connect(&l, &login::loginSuccess, [&](int id, int r) {
        uid = id;
        role = r;
        // 从数据库查询用户名（此处简化，实际需根据ID查询）
        userName = "管理员" + QString::number(uid);  // 示例：用户名=管理员+ID
    });

    if (l.exec() == QDialog::Accepted) {
        if (role == 1) {  // 管理员角色
            AdminWindow *adminWin = new AdminWindow(uid, userName);  // 传递ID和用户名
            adminWin->show();
            return a.exec();
        } else if (role == 0) {  // 物业工作人员
            StaffWindow *staffWin = new StaffWindow(uid);
            staffWin->show();
            return a.exec();
        } else if (role == 2) {  // 业主
            OwnerWindow *ownerWin = new OwnerWindow(uid);
            ownerWin->show();
            return a.exec();
        } else {
            QMessageBox::warning(nullptr, "错误", "未知角色！");
            return 0;
        }
    }
    return 0;
}
