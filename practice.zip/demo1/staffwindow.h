#ifndef STAFFWINDOW_H
#define STAFFWINDOW_H

#include <QMainWindow>

namespace Ui {
class StaffWindow;
}

class StaffWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit StaffWindow(int id,QWidget *parent = nullptr);
    ~StaffWindow();

private:
    Ui::StaffWindow *ui;
    int m_uid;
};

#endif // STAFFWINDOW_H
