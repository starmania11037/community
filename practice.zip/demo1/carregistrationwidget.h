#ifndef CARREGISTRATIONWIDGET_H
#define CARREGISTRATIONWIDGET_H

#include <QWidget>
#include <QTableWidget>
#include <QPushButton>

namespace Ui {
class CarRegistrationWidget;
}

class CarRegistrationWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CarRegistrationWidget(QWidget *parent = nullptr);
    ~CarRegistrationWidget();

private:
    Ui::CarRegistrationWidget *ui;
    QTableWidget* table;
    QPushButton* btnAdd;
    QPushButton* btnEdit;
    QPushButton* btnDelete;
    QPushButton* btnConsult;
    void onAdd();
    void onEdit();
    void onDelete();

private slots:
    void refreshTable();
};

#endif // CARREGISTRATIONWIDGET_H
