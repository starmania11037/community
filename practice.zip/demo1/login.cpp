#include "login.h"
#include "ui_login.h"
#include <QDebug>
#include <QMessageBox>
#include "database.h"

login::login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::login)
{
    ui -> setupUi(this);
    m_usernameEdit = ui -> lineEdit;
    m_passwordEdit = ui -> lineEdit_2;
    m_loginBtn = ui -> pushButton;
    m_registerBtn = ui -> pushButton_2;

    if(!db.openDB("user.db")){
        QMessageBox::critical(this,"错误","打开数据库失败！");
    }



    connect(m_loginBtn, &QPushButton::clicked,this,&login::onLoginClicked);
    connect(m_registerBtn, &QPushButton::clicked,this,&login::onExitClicked);//每一个类被创建都会有一个指针，指自己。信号和槽响应函数
}

void login::onLoginClicked(){

    QString un = m_usernameEdit ->text().trimmed();           //获取用户名，读取并删除空白
    QString pw = m_passwordEdit ->text();          //获取密码
    if(un.isEmpty() || pw.isEmpty()){
        QMessageBox::warning(this,"提示","请输入用户名和密码！");
        return;
    }

    QSqlQuery query  =  db.getUserByUsername(un);
    if(query.next()){
        QString dbpw = query.value("password").toString();
        if(dbpw != pw){
            QMessageBox::warning(this,"登陆失败","密码错误！");
            return;
        }

        int uid = query.value("id").toInt();
        int role = query.value("role").toInt();
        qDebug() << "登录成功！用户ID：" << uid << "，角色：" << role; // 关键调试
        emit loginSuccess(uid,role);

        accept();
    }
    else {
        QMessageBox::warning(this,"登陆失败","用户不存在，请先注册！");
        return;
    }
}
void login::onExitClicked(){
    reject();
}
login::~login()
{
    delete ui;
}
