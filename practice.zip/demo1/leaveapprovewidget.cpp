#include "leaveapprovewidget.h"
#include "ui_leaveapprovewidget.h"
#include "database.h"

#include <QVBoxLayout>
#include <QDebug>
#include <QHeaderView>
#include <QMessageBox>
#include <QDateTime>

LeaveApproveWidget::LeaveApproveWidget(QWidget* parent) : QWidget(parent) {
    qDebug() << "LeaveApproveWidget is running";
    table = new QTableWidget(this);
    table->setColumnCount(8);
    table->setHorizontalHeaderLabels({"ID", "员工ID", "开始日期", "结束日期", "原因", "状态", "审批人ID", "审批时间"});
    table->horizontalHeader()-> setSectionResizeMode(QHeaderView::Stretch);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);

    btnApprove = new QPushButton("批准", this);
    btnReject = new QPushButton("拒绝", this);

    auto* btnLayout = new QHBoxLayout;
    btnLayout->addWidget(btnApprove);
    btnLayout->addWidget(btnReject);
    btnLayout->addStretch();

    auto* mainLayout = new QVBoxLayout(this);
    mainLayout->addLayout(btnLayout);
    mainLayout->addWidget(table);

    connect(btnApprove, &QPushButton::clicked, this, &LeaveApproveWidget::onApprove);
    connect(btnReject, &QPushButton::clicked, this, &LeaveApproveWidget::onReject);

    refreshTable();
}

void LeaveApproveWidget::refreshTable() {
//    table->setRowCount(0);
//    DataBase db;
//    db.openDB("staff.db");
//    QString m = "SELECT id,staffname,start_date,end_date,reason,status,appover_id,approve_time From leave";
//    QSqlQuery query = db.query(m,QVariantList());
//    int row = 0;
//    while (query.next()) {
//    table->insertRow(row);
//    for (int col = 0; col < 8; ++col) {
//    QString val = query.value(col).toString();
//    if (col == 5) { // 状态
//    int status = query.value(col).toInt();
//    if (status == 0) val = "待审批";
//    else if (status == 1) val = "已批准";
//    else if (status == 2) val = "已拒绝";
//    }
//    table->setItem(row, col, new QTableWidgetItem(val));
//    }
//    ++row;
//    }
}
void LeaveApproveWidget::onApprove() {
//    int row = table->currentRow();
//    if (row < 0) return;
//    int leave_id = table->item(row, 0)->text().toInt();
//    int status = table->item(row, 5)->text() == "待审批" ? 0 : 1;
//    if (status != 0) {
//        QMessageBox::information(this, "提示", "该申请已审批！");
//        return;
//    }
//    // 这里假设管理员ID为1，可根据实际登录用户ID传递
//    int approver_id = 1;
//    QString approve_time = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");

//    DataBase db;
//    db.openDB("smart.db");
//    QSqlQuery q;
//    q.prepare("UPDATE leaves SET status=1, approver_id=?, approve_time=? WHERE id=?");
//    q.addBindValue(approver_id);
//    q.addBindValue(approve_time);
//    q.addBindValue(leave_id);
//    if (q.exec()) {
//        QMessageBox::information(this, "成功", "已批准该请假申请！");
//        refreshTable();
//    } else {
//        QMessageBox::warning(this, "失败", "操作失败！");
//    }
}
void LeaveApproveWidget::onReject() {

}

LeaveApproveWidget::~LeaveApproveWidget()
{
    delete ui;
}
