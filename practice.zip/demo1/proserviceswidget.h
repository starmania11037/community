#ifndef PROSERVICESWIDGET_H
#define PROSERVICESWIDGET_H

#include <QWidget>

namespace Ui {
class ProServicesWidget;
}

class ProServicesWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ProServicesWidget(QWidget *parent = nullptr);
    ~ProServicesWidget();

private:
    Ui::ProServicesWidget *ui;
};

#endif // PROSERVICESWIDGET_H
