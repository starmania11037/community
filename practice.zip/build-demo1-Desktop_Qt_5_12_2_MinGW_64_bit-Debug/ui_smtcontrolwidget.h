/********************************************************************************
** Form generated from reading UI file 'smtcontrolwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SMTCONTROLWIDGET_H
#define UI_SMTCONTROLWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SmtControlWidget
{
public:

    void setupUi(QWidget *SmtControlWidget)
    {
        if (SmtControlWidget->objectName().isEmpty())
            SmtControlWidget->setObjectName(QString::fromUtf8("SmtControlWidget"));
        SmtControlWidget->resize(400, 300);

        retranslateUi(SmtControlWidget);

        QMetaObject::connectSlotsByName(SmtControlWidget);
    } // setupUi

    void retranslateUi(QWidget *SmtControlWidget)
    {
        SmtControlWidget->setWindowTitle(QApplication::translate("SmtControlWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SmtControlWidget: public Ui_SmtControlWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SMTCONTROLWIDGET_H
