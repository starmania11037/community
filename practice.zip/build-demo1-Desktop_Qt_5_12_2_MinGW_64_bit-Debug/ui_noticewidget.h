/********************************************************************************
** Form generated from reading UI file 'noticewidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOTICEWIDGET_H
#define UI_NOTICEWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NoticeWidget
{
public:

    void setupUi(QWidget *NoticeWidget)
    {
        if (NoticeWidget->objectName().isEmpty())
            NoticeWidget->setObjectName(QString::fromUtf8("NoticeWidget"));
        NoticeWidget->resize(400, 300);

        retranslateUi(NoticeWidget);

        QMetaObject::connectSlotsByName(NoticeWidget);
    } // setupUi

    void retranslateUi(QWidget *NoticeWidget)
    {
        NoticeWidget->setWindowTitle(QApplication::translate("NoticeWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NoticeWidget: public Ui_NoticeWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOTICEWIDGET_H
