/********************************************************************************
** Form generated from reading UI file 'proserviceswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROSERVICESWIDGET_H
#define UI_PROSERVICESWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ProServicesWidget
{
public:

    void setupUi(QWidget *ProServicesWidget)
    {
        if (ProServicesWidget->objectName().isEmpty())
            ProServicesWidget->setObjectName(QString::fromUtf8("ProServicesWidget"));
        ProServicesWidget->resize(400, 300);

        retranslateUi(ProServicesWidget);

        QMetaObject::connectSlotsByName(ProServicesWidget);
    } // setupUi

    void retranslateUi(QWidget *ProServicesWidget)
    {
        ProServicesWidget->setWindowTitle(QApplication::translate("ProServicesWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProServicesWidget: public Ui_ProServicesWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROSERVICESWIDGET_H
