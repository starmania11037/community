/********************************************************************************
** Form generated from reading UI file 'myhomewidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYHOMEWIDGET_H
#define UI_MYHOMEWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MyHomeWidget
{
public:

    void setupUi(QWidget *MyHomeWidget)
    {
        if (MyHomeWidget->objectName().isEmpty())
            MyHomeWidget->setObjectName(QString::fromUtf8("MyHomeWidget"));
        MyHomeWidget->resize(400, 300);

        retranslateUi(MyHomeWidget);

        QMetaObject::connectSlotsByName(MyHomeWidget);
    } // setupUi

    void retranslateUi(QWidget *MyHomeWidget)
    {
        MyHomeWidget->setWindowTitle(QApplication::translate("MyHomeWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MyHomeWidget: public Ui_MyHomeWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYHOMEWIDGET_H
