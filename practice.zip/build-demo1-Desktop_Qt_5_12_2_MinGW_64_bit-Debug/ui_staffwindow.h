/********************************************************************************
** Form generated from reading UI file 'staffwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STAFFWINDOW_H
#define UI_STAFFWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StaffWindow
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *StaffWindow)
    {
        if (StaffWindow->objectName().isEmpty())
            StaffWindow->setObjectName(QString::fromUtf8("StaffWindow"));
        StaffWindow->resize(800, 600);
        menubar = new QMenuBar(StaffWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        StaffWindow->setMenuBar(menubar);
        centralwidget = new QWidget(StaffWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        StaffWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(StaffWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        StaffWindow->setStatusBar(statusbar);

        retranslateUi(StaffWindow);

        QMetaObject::connectSlotsByName(StaffWindow);
    } // setupUi

    void retranslateUi(QMainWindow *StaffWindow)
    {
        StaffWindow->setWindowTitle(QApplication::translate("StaffWindow", "MainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StaffWindow: public Ui_StaffWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STAFFWINDOW_H
