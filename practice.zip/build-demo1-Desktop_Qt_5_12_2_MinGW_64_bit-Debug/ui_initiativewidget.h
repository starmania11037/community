/********************************************************************************
** Form generated from reading UI file 'initiativewidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INITIATIVEWIDGET_H
#define UI_INITIATIVEWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_InitiativeWidget
{
public:

    void setupUi(QWidget *InitiativeWidget)
    {
        if (InitiativeWidget->objectName().isEmpty())
            InitiativeWidget->setObjectName(QString::fromUtf8("InitiativeWidget"));
        InitiativeWidget->resize(400, 300);

        retranslateUi(InitiativeWidget);

        QMetaObject::connectSlotsByName(InitiativeWidget);
    } // setupUi

    void retranslateUi(QWidget *InitiativeWidget)
    {
        InitiativeWidget->setWindowTitle(QApplication::translate("InitiativeWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class InitiativeWidget: public Ui_InitiativeWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INITIATIVEWIDGET_H
