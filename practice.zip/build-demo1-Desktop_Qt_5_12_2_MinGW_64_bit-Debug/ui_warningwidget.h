/********************************************************************************
** Form generated from reading UI file 'warningwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WARNINGWIDGET_H
#define UI_WARNINGWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_WarningWidget
{
public:

    void setupUi(QWidget *WarningWidget)
    {
        if (WarningWidget->objectName().isEmpty())
            WarningWidget->setObjectName(QString::fromUtf8("WarningWidget"));
        WarningWidget->resize(400, 300);

        retranslateUi(WarningWidget);

        QMetaObject::connectSlotsByName(WarningWidget);
    } // setupUi

    void retranslateUi(QWidget *WarningWidget)
    {
        WarningWidget->setWindowTitle(QApplication::translate("WarningWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class WarningWidget: public Ui_WarningWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WARNINGWIDGET_H
