/********************************************************************************
** Form generated from reading UI file 'attendancewidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ATTENDANCEWIDGET_H
#define UI_ATTENDANCEWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AttendanceWidget
{
public:

    void setupUi(QWidget *AttendanceWidget)
    {
        if (AttendanceWidget->objectName().isEmpty())
            AttendanceWidget->setObjectName(QString::fromUtf8("AttendanceWidget"));
        AttendanceWidget->resize(400, 300);

        retranslateUi(AttendanceWidget);

        QMetaObject::connectSlotsByName(AttendanceWidget);
    } // setupUi

    void retranslateUi(QWidget *AttendanceWidget)
    {
        AttendanceWidget->setWindowTitle(QApplication::translate("AttendanceWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AttendanceWidget: public Ui_AttendanceWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ATTENDANCEWIDGET_H
