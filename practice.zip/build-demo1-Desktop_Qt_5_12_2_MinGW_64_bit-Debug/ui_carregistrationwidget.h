/********************************************************************************
** Form generated from reading UI file 'carregistrationwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CARREGISTRATIONWIDGET_H
#define UI_CARREGISTRATIONWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CarRegistrationWidget
{
public:

    void setupUi(QWidget *CarRegistrationWidget)
    {
        if (CarRegistrationWidget->objectName().isEmpty())
            CarRegistrationWidget->setObjectName(QString::fromUtf8("CarRegistrationWidget"));
        CarRegistrationWidget->resize(400, 300);

        retranslateUi(CarRegistrationWidget);

        QMetaObject::connectSlotsByName(CarRegistrationWidget);
    } // setupUi

    void retranslateUi(QWidget *CarRegistrationWidget)
    {
        CarRegistrationWidget->setWindowTitle(QApplication::translate("CarRegistrationWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CarRegistrationWidget: public Ui_CarRegistrationWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CARREGISTRATIONWIDGET_H
