/********************************************************************************
** Form generated from reading UI file 'announcementwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ANNOUNCEMENTWINDOW_H
#define UI_ANNOUNCEMENTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AnnouncementWindow
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *AnnouncementWindow)
    {
        if (AnnouncementWindow->objectName().isEmpty())
            AnnouncementWindow->setObjectName(QString::fromUtf8("AnnouncementWindow"));
        AnnouncementWindow->resize(800, 600);
        menubar = new QMenuBar(AnnouncementWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        AnnouncementWindow->setMenuBar(menubar);
        centralwidget = new QWidget(AnnouncementWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        AnnouncementWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(AnnouncementWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        AnnouncementWindow->setStatusBar(statusbar);

        retranslateUi(AnnouncementWindow);

        QMetaObject::connectSlotsByName(AnnouncementWindow);
    } // setupUi

    void retranslateUi(QMainWindow *AnnouncementWindow)
    {
        AnnouncementWindow->setWindowTitle(QApplication::translate("AnnouncementWindow", "MainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AnnouncementWindow: public Ui_AnnouncementWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ANNOUNCEMENTWINDOW_H
