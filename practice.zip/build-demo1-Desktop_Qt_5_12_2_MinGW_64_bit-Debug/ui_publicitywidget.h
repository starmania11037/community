/********************************************************************************
** Form generated from reading UI file 'publicitywidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PUBLICITYWIDGET_H
#define UI_PUBLICITYWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PublicityWidget
{
public:

    void setupUi(QWidget *PublicityWidget)
    {
        if (PublicityWidget->objectName().isEmpty())
            PublicityWidget->setObjectName(QString::fromUtf8("PublicityWidget"));
        PublicityWidget->resize(400, 300);

        retranslateUi(PublicityWidget);

        QMetaObject::connectSlotsByName(PublicityWidget);
    } // setupUi

    void retranslateUi(QWidget *PublicityWidget)
    {
        PublicityWidget->setWindowTitle(QApplication::translate("PublicityWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PublicityWidget: public Ui_PublicityWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PUBLICITYWIDGET_H
