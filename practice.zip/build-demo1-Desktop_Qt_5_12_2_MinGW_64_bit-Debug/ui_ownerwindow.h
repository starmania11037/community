/********************************************************************************
** Form generated from reading UI file 'ownerwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OWNERWINDOW_H
#define UI_OWNERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_OwnerWindow
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *OwnerWindow)
    {
        if (OwnerWindow->objectName().isEmpty())
            OwnerWindow->setObjectName(QString::fromUtf8("OwnerWindow"));
        OwnerWindow->resize(800, 600);
        menubar = new QMenuBar(OwnerWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        OwnerWindow->setMenuBar(menubar);
        centralwidget = new QWidget(OwnerWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        OwnerWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(OwnerWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        OwnerWindow->setStatusBar(statusbar);

        retranslateUi(OwnerWindow);

        QMetaObject::connectSlotsByName(OwnerWindow);
    } // setupUi

    void retranslateUi(QMainWindow *OwnerWindow)
    {
        OwnerWindow->setWindowTitle(QApplication::translate("OwnerWindow", "MainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class OwnerWindow: public Ui_OwnerWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OWNERWINDOW_H
