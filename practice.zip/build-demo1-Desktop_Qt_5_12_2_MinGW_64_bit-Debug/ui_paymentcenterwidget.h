/********************************************************************************
** Form generated from reading UI file 'paymentcenterwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAYMENTCENTERWIDGET_H
#define UI_PAYMENTCENTERWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PaymentCenter
{
public:

    void setupUi(QWidget *PaymentCenter)
    {
        if (PaymentCenter->objectName().isEmpty())
            PaymentCenter->setObjectName(QString::fromUtf8("PaymentCenter"));
        PaymentCenter->resize(400, 300);

        retranslateUi(PaymentCenter);

        QMetaObject::connectSlotsByName(PaymentCenter);
    } // setupUi

    void retranslateUi(QWidget *PaymentCenter)
    {
        PaymentCenter->setWindowTitle(QApplication::translate("PaymentCenter", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PaymentCenter: public Ui_PaymentCenter {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAYMENTCENTERWIDGET_H
