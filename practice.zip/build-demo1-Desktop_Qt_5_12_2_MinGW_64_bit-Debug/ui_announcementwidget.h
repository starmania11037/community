/********************************************************************************
** Form generated from reading UI file 'announcementwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ANNOUNCEMENTWIDGET_H
#define UI_ANNOUNCEMENTWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AnnouncementWidget
{
public:

    void setupUi(QWidget *AnnouncementWidget)
    {
        if (AnnouncementWidget->objectName().isEmpty())
            AnnouncementWidget->setObjectName(QString::fromUtf8("AnnouncementWidget"));
        AnnouncementWidget->resize(400, 300);

        retranslateUi(AnnouncementWidget);

        QMetaObject::connectSlotsByName(AnnouncementWidget);
    } // setupUi

    void retranslateUi(QWidget *AnnouncementWidget)
    {
        AnnouncementWidget->setWindowTitle(QApplication::translate("AnnouncementWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AnnouncementWidget: public Ui_AnnouncementWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ANNOUNCEMENTWIDGET_H
