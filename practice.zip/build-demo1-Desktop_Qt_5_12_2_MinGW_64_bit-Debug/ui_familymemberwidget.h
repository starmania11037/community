/********************************************************************************
** Form generated from reading UI file 'familymemberwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FAMILYMEMBERWIDGET_H
#define UI_FAMILYMEMBERWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FamilyMemberWidget
{
public:

    void setupUi(QWidget *FamilyMemberWidget)
    {
        if (FamilyMemberWidget->objectName().isEmpty())
            FamilyMemberWidget->setObjectName(QString::fromUtf8("FamilyMemberWidget"));
        FamilyMemberWidget->resize(16, 16);

        retranslateUi(FamilyMemberWidget);

        QMetaObject::connectSlotsByName(FamilyMemberWidget);
    } // setupUi

    void retranslateUi(QWidget *FamilyMemberWidget)
    {
        FamilyMemberWidget->setWindowTitle(QApplication::translate("FamilyMemberWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FamilyMemberWidget: public Ui_FamilyMemberWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FAMILYMEMBERWIDGET_H
