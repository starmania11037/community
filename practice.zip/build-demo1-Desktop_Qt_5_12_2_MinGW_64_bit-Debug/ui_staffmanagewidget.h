/********************************************************************************
** Form generated from reading UI file 'staffmanagewidget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STAFFMANAGEWIDGET_H
#define UI_STAFFMANAGEWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StaffManageWidget
{
public:

    void setupUi(QWidget *StaffManageWidget)
    {
        if (StaffManageWidget->objectName().isEmpty())
            StaffManageWidget->setObjectName(QString::fromUtf8("StaffManageWidget"));
        StaffManageWidget->resize(400, 300);

        retranslateUi(StaffManageWidget);

        QMetaObject::connectSlotsByName(StaffManageWidget);
    } // setupUi

    void retranslateUi(QWidget *StaffManageWidget)
    {
        StaffManageWidget->setWindowTitle(QApplication::translate("StaffManageWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StaffManageWidget: public Ui_StaffManageWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STAFFMANAGEWIDGET_H
